
����	IRS�ڵ�	�׸鰡(���)	03M	01Y	02Y	03Y	04Y	05Y	07Y	10Y	12Y	15Y	20Y


select *FROM hedgeos.dbo.Greeks_IR where date = '2021-04-05'

select distinct(productcode) FROM hedgeos.dbo.Greeks_IR where date = '2021-04-05' and type = 'asset' and userid ='15'

select distinct(productcode) from hedgeos.dbo.HoldingList where date ='2021-04-05' and type = 'SWAP'


SELECT * FROM (
	SELECT
	a.date
	,b.ProductCode
	,b.Notional
	,a.tenor
	,b.position
	,a.Value
	FROM hedgeos.dbo.Greeks_IR A inner join hedgeos.dbo.holdinglist B on ((A.ProductCode = b.ProductCode) and (a.userid = b.userid) and (a.date = b.date))
	WHERE a.userid = '15' and a.greeks = 'RHO' and a.type = 'asset' and  a.date = '2022-01-11'
) AS RESULT
PIVOT (SUM(VALUE) FOR tenor IN (
[03M],
[01Y],
[02Y],[03Y],[04Y],[05Y],[07Y],[10Y],[12Y],[15Y],[20Y])
) AS PIVOT_RESULT order by ProductCode asc


select * from hedgeos.dbo.swap_info



 --���ǥ--

 
 declare @date as date
 set @date = '2021-04-09'

select * from
(
 select 
  case when B.position = '-1' then 'Rec' else 'Pay' end as [Position], A.Tenor,
  sum(B.Notional) as [Notional��]
 from (select swapcode, 
 case
 when datediff(yy, @date , maturity) = 0 then '0'
 when datediff(yy, @date , maturity) = 1 then '1'
 when datediff(yy, @date , maturity) = 2 then '2'
 when datediff(yy, @date , maturity) = 3 then '3'
 when datediff(yy, @date , maturity) = 4 then '4'
 when datediff(yy, @date , maturity) = 5 then '5'
 when datediff(yy, @date , maturity) = 6 then '6'
 when datediff(yy, @date , maturity) = 7 then  '7' 
 when datediff(yy, @date , maturity) = 8 then  '8' 
 when datediff(yy, @date , maturity) = 9 then  '9' 
 when datediff(yy, @date , maturity) = 10 then '10'
 when datediff(yy, @date , maturity) = 11 then '11'
 when datediff(yy, @date , maturity) = 12 then '12'
 when datediff(yy, @date , maturity) = 13 then '13'
 when datediff(yy, @date , maturity) = 14 then '14'
 when datediff(yy, @date , maturity) = 15 then '15'
 when datediff(yy, @date , maturity) = 16 then '16'
 when datediff(yy, @date , maturity) = 17 then '17'
 when datediff(yy, @date , maturity) = 18 then '18'
 when datediff(yy, @date , maturity) = 19 then '19'
 when datediff(yy, @date , maturity) = 20 then '20'
 end as [Tenor] from hedgeos.dbo.swap_info) A inner join 
 (select * from hedgeos.dbo.HoldingList where userid = '15' and type = 'Swap' and date = @date) B
 on A.SwapCode = B.ProductCode
 group by B.position, [Tenor]
) as result
pivot (sum([Notional��]) for [Tenor] in
([0],[1],[2],[3],[4],[5],[7],[10],[12],[15],[20])) as pivot_result








strSQL = strSQL & vbCrLf & " declare @date as date"
strSQL = strSQL & vbCrLf & " set @date = '" & Format(todaysDate, "yyyy-MM-dd") & "'"
strSQL = strSQL & vbCrLf & " select"
strSQL = strSQL & vbCrLf & "  case when B.position = '-1' then 'Rec' else 'Pay' end as [Position], A.Tenor,"
strSQL = strSQL & vbCrLf & "  sum(B.Notional) as [Notional��]"
strSQL = strSQL & vbCrLf & " from (select swapcode, "
strSQL = strSQL & vbCrLf & " case"
strSQL = strSQL & vbCrLf & " when datediff(yy, @date , maturity) = 0 then '0'"
strSQL = strSQL & vbCrLf & " when datediff(yy, @date , maturity) = 1 then '1'"
strSQL = strSQL & vbCrLf & " when datediff(yy, @date , maturity) = 2 then '2'"
strSQL = strSQL & vbCrLf & " when datediff(yy, @date , maturity) = 3 then '3'"
strSQL = strSQL & vbCrLf & " when datediff(yy, @date , maturity) = 4 then '4'"
strSQL = strSQL & vbCrLf & " when datediff(yy, @date , maturity) = 5 then '5'"
strSQL = strSQL & vbCrLf & " when datediff(yy, @date , maturity) = 6 then '6'"
strSQL = strSQL & vbCrLf & " when datediff(yy, @date , maturity) = 7 then  '7' "
strSQL = strSQL & vbCrLf & " when datediff(yy, @date , maturity) = 8 then  '8' "
strSQL = strSQL & vbCrLf & " when datediff(yy, @date , maturity) = 9 then  '9' "
strSQL = strSQL & vbCrLf & " when datediff(yy, @date , maturity) = 10 then '10'"
strSQL = strSQL & vbCrLf & " when datediff(yy, @date , maturity) = 11 then '11'"
strSQL = strSQL & vbCrLf & " when datediff(yy, @date , maturity) = 12 then '12'"
strSQL = strSQL & vbCrLf & " when datediff(yy, @date , maturity) = 13 then '13'"
strSQL = strSQL & vbCrLf & " when datediff(yy, @date , maturity) = 14 then '14'"
strSQL = strSQL & vbCrLf & " when datediff(yy, @date , maturity) = 15 then '15'"
strSQL = strSQL & vbCrLf & " when datediff(yy, @date , maturity) = 16 then '16'"
strSQL = strSQL & vbCrLf & " when datediff(yy, @date , maturity) = 17 then '17'"
strSQL = strSQL & vbCrLf & " when datediff(yy, @date , maturity) = 18 then '18'"
strSQL = strSQL & vbCrLf & " when datediff(yy, @date , maturity) = 19 then '19'"
strSQL = strSQL & vbCrLf & " when datediff(yy, @date , maturity) = 20 then '20'"
strSQL = strSQL & vbCrLf & " end as [Tenor] from hedgeos.dbo.swap_info) A inner join "
strSQL = strSQL & vbCrLf & " (select * from hedgeos.dbo.HoldingList where userid = '15' and type = 'Swap' and date = @date) B"
strSQL = strSQL & vbCrLf & " on A.SwapCode = B.ProductCode"
strSQL = strSQL & vbCrLf & " group by B.position, [Tenor]"
strSQL = strSQL & vbCrLf & " order by position,"
strSQL = strSQL & vbCrLf & " case tenor"
strSQL = strSQL & vbCrLf & " when '1' then 1" 
strSQL = strSQL & vbCrLf & " when '2' then 2" 
strSQL = strSQL & vbCrLf & " when '3' then 3" 
strSQL = strSQL & vbCrLf & " when '4' then 4" 
strSQL = strSQL & vbCrLf & " when '5' then 5" 
strSQL = strSQL & vbCrLf & " when '6'  then 6"  
strSQL = strSQL & vbCrLf & " when '7'  then 7"  
strSQL = strSQL & vbCrLf & " when '8'  then 8"  
strSQL = strSQL & vbCrLf & " when '9'  then 9"  
strSQL = strSQL & vbCrLf & " when '10' then 10" 
strSQL = strSQL & vbCrLf & " when '11' then 11" 
strSQL = strSQL & vbCrLf & " when '12' then 12" 
strSQL = strSQL & vbCrLf & " when '13' then 13" 
strSQL = strSQL & vbCrLf & " when '14' then 14" 
strSQL = strSQL & vbCrLf & " when '15' then 15" 
strSQL = strSQL & vbCrLf & " when '16' then 16" 
strSQL = strSQL & vbCrLf & " when '17' then 17" 
strSQL = strSQL & vbCrLf & " when '18' then  18"
strSQL = strSQL & vbCrLf & "when  '19' then	  19"
strSQL = strSQL & vbCrLf & "when  '20' then	  20 end"