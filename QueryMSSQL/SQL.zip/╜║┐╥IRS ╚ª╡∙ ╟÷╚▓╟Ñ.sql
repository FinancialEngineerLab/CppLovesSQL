




 select * from hanwhainput.dbo.IRSwap where InstrumentType = 'IRSwap'

 select * from hanwhainput.dbo.InputMaster

 


 -- Tenory
 select * from hedgeos.dbo.Swap_Info
 
 -- Position and Notional AMount
 select * from hedgeos.dbo.HoldingList where userid = '15' and type = 'Swap' and date = '2020-12-30'
 

 --���ǥ--
 select 
  case when B.position = '-1' then 'Rec' else 'Pay' end as [Position], A.Tenor,
  sum(B.Notional) as [Notional��]
 from (select swapcode, 
 case when substring(swapcode, 10, 2) = '01' then '1' 
 when substring(swapcode, 10, 2) = '02' then '2' 
 when substring(swapcode, 10, 2) = '03' then '3' 
 when substring(swapcode, 10, 2) = '04' then '4' 
 when substring(swapcode, 10, 2) = '05' then '5' 
 when substring(swapcode, 10, 2) = '07' then '7' 
 when substring(swapcode, 10, 2) = '10' then '10' 
 when substring(swapcode, 10, 2) = '12' then '12' 
 when substring(swapcode, 10, 2) = '15' then '15' 
 when substring(swapcode, 10, 2) = '20' then '20' end as [Tenor] from hedgeos.dbo.swap_info) A inner join 
 (select * from hedgeos.dbo.HoldingList where userid = '15' and type = 'Swap' and date = '2021-10-29') B
 on A.SwapCode = B.ProductCode
 group by B.position, [Tenor] order by Tenor

  --���ǥ ��ǥ�� REC--
 select 
  case when B.position = '-1' then 'Rec' else 'Pay' end as [Position], sum(B.Notional) as [Notional��]
 from (select swapcode, 
 case when substring(swapcode, 10, 2) = '01' then '1' 
 when substring(swapcode, 10, 2) = '02' then '2' 
 when substring(swapcode, 10, 2) = '03' then '3' 
 when substring(swapcode, 10, 2) = '04' then '4' 
 when substring(swapcode, 10, 2) = '05' then '5' 
 when substring(swapcode, 10, 2) = '07' then '7' 
 when substring(swapcode, 10, 2) = '10' then '10' 
 when substring(swapcode, 10, 2) = '12' then '12' 
 when substring(swapcode, 10, 2) = '15' then '15' 
 when substring(swapcode, 10, 2) = '20' then '20' end as [Tenor] from hedgeos.dbo.swap_info) A inner join 
 (select * from hedgeos.dbo.HoldingList where userid = '15' and type = 'Swap'and date = '2021-03-30') B
 on A.SwapCode = B.ProductCode
 where  Position = 'Rec'
 group by B.position
 
  --���ǥ ��ǥ�� REC--
 select 
  case when B.position = '-1' then 'Rec' else 'Pay' end as [Position], sum(B.Notional) as [Notional��]
 from (select swapcode, 
 case when substring(swapcode, 10, 2) = '01' then '1' 
 when substring(swapcode, 10, 2) = '02' then '2' 
 when substring(swapcode, 10, 2) = '03' then '3' 
 when substring(swapcode, 10, 2) = '04' then '4' 
 when substring(swapcode, 10, 2) = '05' then '5' 
 when substring(swapcode, 10, 2) = '07' then '7' 
 when substring(swapcode, 10, 2) = '10' then '10' 
 when substring(swapcode, 10, 2) = '12' then '12' 
 when substring(swapcode, 10, 2) = '15' then '15' 
 when substring(swapcode, 10, 2) = '20' then '20' end as [Tenor] from hedgeos.dbo.swap_info) A inner join 
 (select * from hedgeos.dbo.HoldingList where userid = '15' and type = 'Swap') B
 on A.SwapCode = B.ProductCode
 where  Position = 'Pay'and B.date = '2021-03-29'
 group by B.position
 


 select A.swapcode, case when B.position = '-1' then 'Rec' else 'Pay' end as [Position], B.Notional,
 case when substring(A.swapcode, 10, 2) = '01' then '1' 
 when substring(A.swapcode, 10, 2) = '02' then '2' 
 when substring(A.swapcode, 10, 2) = '03' then '3' 
 when substring(A.swapcode, 10, 2) = '04' then '4' 
 when substring(A.swapcode, 10, 2) = '05' then '5' 
 when substring(A.swapcode, 10, 2) = '07' then '7' 
 when substring(A.swapcode, 10, 2) = '10' then '10' 
 when substring(A.swapcode, 10, 2) = '12' then '12' 
 when substring(A.swapcode, 10, 2) = '15' then '15' 
 when substring(A.swapcode, 10, 2) = '20' then '20' end as [Tenor]
 from hedgeos.dbo.swap_info A inner join 
 (select * from hedgeos.dbo.HoldingList where userid = '15' and type = 'Swap' and date = '2021-03-30') B
 on A.SwapCode = B.ProductCode


 select case when B.position = '-1' then 'Rec' else 'Pay' end as [Position], sum(B.Notional) as [Notional��], A.lenghtInYears as [Tenor] from hedgeos.dbo.swap_info A inner join 
 (select * from hedgeos.dbo.HoldingList where userid = '15' and type = 'Swap' and date = '2021-03-29') B
 on A.SwapCode = B.ProductCode
 group by B.position, A.lenghtInYears




 


 select Position
,isnull([1], 0) / 100000000 AS [1Y]
,isnull([2], 0) / 100000000 AS [2Y]
,isnull([3], 0) / 100000000 AS [3Y]
,isnull([4], 0) / 100000000 AS [4Y]
,isnull([5], 0) / 100000000 AS [5Y]
,isnull([7], 0) / 100000000 AS [7Y]
,isnull([10], 0) / 100000000  AS [10Y]
,isnull([12], 0) / 100000000 AS [12Y]
,isnull([15], 0) / 100000000 AS [15Y]
,isnull([20], 0) / 100000000 AS [20]
 from
(
select
 case when B.position = '-1' then 'Rec' else 'Pay' end as [Position], A.Tenor,
 sum(B.Notional) as [Notional��]
from (select swapcode, 
case
when (datediff(mm, '2021-10-29', maturity) >=0) and (datediff(mm, '2021-10-29', maturity) <=18) then '1'
when (datediff(mm, '2021-10-29', maturity) >18) and (datediff(mm, '2021-10-29', maturity) <=30) then '2'
when (datediff(mm, '2021-10-29', maturity) >30) and (datediff(mm, '2021-10-29', maturity) <=42) then '3'
when (datediff(mm, '2021-10-29', maturity) >42) and (datediff(mm, '2021-10-29', maturity) <=54) then '4'
when (datediff(mm, '2021-10-29', maturity) >54) and (datediff(mm, '2021-10-29', maturity) <=72) then '5'
when (datediff(mm, '2021-10-29', maturity) >72) and (datediff(mm, '2021-10-29', maturity) <=102) then '7'
when (datediff(mm, '2021-10-29', maturity) >102) and (datediff(mm,'2021-10-29', maturity) <=132) then '10'
when (datediff(mm, '2021-10-29', maturity) >132) and (datediff(mm,'2021-10-29', maturity) <=162) then '12'
when (datediff(mm, '2021-10-29', maturity) >162) and (datediff(mm,'2021-10-29', maturity) <=210) then '15'
when (datediff(mm, '2021-10-29', maturity) >210) then '20'
end as [Tenor] from hedgeos.dbo.swap_info) A inner join 
(select * from hedgeos.dbo.HoldingList where userid = '15' and type = 'Swap' and date = '2021-10-29') B
on A.SwapCode = B.ProductCode
group by B.position, [Tenor]
) as result
pivot (sum([Notional��]) for Tenor in
([1],[2],[3],[4],[5],[7],[10],[12],[15],[20])) as pivot_result
