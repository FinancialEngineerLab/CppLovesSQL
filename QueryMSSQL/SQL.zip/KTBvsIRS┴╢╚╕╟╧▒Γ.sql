

select * from HanwhaComputations.dbo.Job where ValuationDate ='2022-01-06' order by StartAt desc

SELECT * FROM (
	SELECT A.TicketId
	, b.JobName
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView A inner join HanwhaComputations.dbo.job B on A.TicketId = B.TicketId
	WHERE A.TicketId IN (
'13739',
'13738',
'13737',
'13730',
'13729',
'13728',
'13664',
'13663',
'13662',
'13661',
'13660',
'13659'
)
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN (
[PV],
[DELTA],[GAMMA],
[RHO.3M],[RHO.1Y],[RHO.2Y],[RHO.3Y],[RHO.4Y],[RHO.5Y],[RHO.7Y],[RHO.10Y],[RHO.12Y],[RHO.15Y],[RHO.20Y]
)
) AS PIVOT_RESULT-- order by ticketid asc





SELECT * FROM (
	SELECT A.TicketId
	, b.JobName
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-KTB',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView A inner join HanwhaComputations.dbo.job B on A.TicketId = B.TicketId
	WHERE A.TicketId IN (
'13753',
'13752',
'13751',
'13750',
'13749',
'13748'
)
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN (
[PV],
[DELTA],[GAMMA],
[RHO.3M],[RHO.1Y],[RHO.2Y],[RHO.3Y],[RHO.4Y],[RHO.5Y],[RHO.7Y],[RHO.10Y],[RHO.12Y],[RHO.15Y],[RHO.20Y]
)
) AS PIVOT_RESULT-- order by ticketid asc


