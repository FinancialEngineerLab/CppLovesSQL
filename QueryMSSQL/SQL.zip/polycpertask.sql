

select Hedg_blok_dvsn , count(poly_no) / 44.0 / 2.0 / 74.0 as [policypertask] from HanwhaInput.dbo.Schedule where CLOG_YM = '202111'  group by HEDG_BLOK_DVSN order by HEDG_BLOK_DVSN asc