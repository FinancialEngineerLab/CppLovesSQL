SELECT 
a.Date, 
(case when right(a.ProductCode,1) ='P' then 'Payer' when right(a.productcode,1)= 'R' then 'Receiver' end) as [Position],
cast(left(right(a.productcode,7),6) as numeric) / 1000000 as [Coupon],
c.Mid as [MidCoupon],
b.CounterParty,
right(a.ProductType,3) as [Tenor],
b.Notional, AVG(Value) AS Value
FROM 
(SELECT  CAST(invDate AS DATE) AS Date, invDate AS JobSetId, 'Asset' AS Type, RIGHT(invTrdDate, 6) + 'IRS' + REPLICATE('0', 2 - LEN(CAST(FLOOR(DATEDIFF(DD, invTrdDate, invEndDate) 
                               / 365.0) AS VARCHAR))) + CAST(FLOOR(DATEDIFF(DD, invTrdDate, invEndDate) / 365.0) AS VARCHAR) + 'Y' + REPLICATE('0', 6 - LEN(CONVERT(VARCHAR(6), CONVERT(FLOAT, 
                               invFixedRate) * 10000))) + CONVERT(VARCHAR(6), CONVERT(FLOAT, invFixedRate) * 10000) 
                               + (CASE WHEN invFixedPayer = '��ȭ��������' THEN 'P' WHEN invFloatingPayer = '��ȭ��������' THEN 'R' END) AS ProductCode, 'IRS' + REPLICATE('0', 
                               2 - LEN(CAST(FLOOR(DATEDIFF(DD, invTrdDate, invEndDate) / 365.0) AS VARCHAR))) + CAST(FLOOR(DATEDIFF(DD, invTrdDate, invEndDate) / 365.0) AS VARCHAR) 
                               + 'Y' AS ProductType, CAST(invTodayNpv * 1.0E0  AS numeric(28, 1)) 
                               AS Value, '0' AS NumOfPolicy, '15' AS UserId
                FROM     hedgeos.dbo.ZFCFM_MCI_OTC002) AS a
				inner join hedgeos.dbo.HoldingList B on a.ProductCode = b.ProductCode
				inner join hedgeos.dbo.Market_IR c on a.date = c.Tradeday and b.date = c.Tradeday and right(a.ProductType,3) = c.Tenor

where a.date >='2021-09-30'
and right(jobsetid ,6) = left(a.ProductCode, 6)
and c.ProductName like '%IRS%'
and left(a.ProductType, 3) like '%IRS%'

GROUP BY  a.ProductType, b.CounterParty, b.Notional, c.mid, c.Tenor,a.ProductCode, a.Date, b.Position
order by date asc



/* PnL�� View */
SELECT 
a.Date, sum(Value) AS Value
FROM 
(SELECT  CAST(invDate AS DATE) AS Date, invDate AS JobSetId, 'Asset' AS Type, RIGHT(invTrdDate, 6) + 'IRS' + REPLICATE('0', 2 - LEN(CAST(FLOOR(DATEDIFF(DD, invTrdDate, invEndDate) 
                               / 365.0) AS VARCHAR))) + CAST(FLOOR(DATEDIFF(DD, invTrdDate, invEndDate) / 365.0) AS VARCHAR) + 'Y' + REPLICATE('0', 6 - LEN(CONVERT(VARCHAR(6), CONVERT(FLOAT, 
                               invFixedRate) * 10000))) + CONVERT(VARCHAR(6), CONVERT(FLOAT, invFixedRate) * 10000) 
                               + (CASE WHEN invFixedPayer = '��ȭ��������' THEN 'P' WHEN invFloatingPayer = '��ȭ��������' THEN 'R' END) AS ProductCode, 'IRS' + REPLICATE('0', 
                               2 - LEN(CAST(FLOOR(DATEDIFF(DD, invTrdDate, invEndDate) / 365.0) AS VARCHAR))) + CAST(FLOOR(DATEDIFF(DD, invTrdDate, invEndDate) / 365.0) AS VARCHAR) 
                               + 'Y' AS ProductType, CAST(invTodayNpv * 1.0E0  AS numeric(28, 1)) 
                               AS Value, '0' AS NumOfPolicy, '15' AS UserId
                FROM     dbo.ZFCFM_MCI_OTC002) AS a
				inner join hedgeos.dbo.HoldingList B on a.ProductCode = b.ProductCode
				inner join hedgeos.dbo.Market_IR c on a.date = c.Tradeday and b.date = c.Tradeday and right(a.ProductType,3) = c.Tenor
and right(jobsetid ,6) = left(a.ProductCode, 6)
and c.ProductName like '%IRS%'
and left(a.ProductType, 3) like '%IRS%'

GROUP BY  a.Date
order by date asc


SELECT 
a.Date, sum(Value) AS Value
FROM 
(SELECT  CAST(invDate AS DATE) AS Date, invDate AS JobSetId, 'Asset' AS Type, RIGHT(invTrdDate, 6) + 'IRS' + REPLICATE('0', 2 - LEN(CAST(FLOOR(DATEDIFF(DD, invTrdDate, invEndDate) 
                               / 365.0) AS VARCHAR))) + CAST(FLOOR(DATEDIFF(DD, invTrdDate, invEndDate) / 365.0) AS VARCHAR) + 'Y' + REPLICATE('0', 6 - LEN(CONVERT(VARCHAR(6), CONVERT(FLOAT, 
                               invFixedRate) * 10000))) + CONVERT(VARCHAR(6), CONVERT(FLOAT, invFixedRate) * 10000) 
                               + (CASE WHEN invFixedPayer = '��ȭ��������' THEN 'P' WHEN invFloatingPayer = '��ȭ��������' THEN 'R' END) AS ProductCode, 'IRS' + REPLICATE('0', 
                               2 - LEN(CAST(FLOOR(DATEDIFF(DD, invTrdDate, invEndDate) / 365.0) AS VARCHAR))) + CAST(FLOOR(DATEDIFF(DD, invTrdDate, invEndDate) / 365.0) AS VARCHAR) 
                               + 'Y' AS ProductType, CAST(invTodayNpv * 1.0E0  AS numeric(28, 1)) 
                               AS Value, '0' AS NumOfPolicy, '15' AS UserId
                FROM     dbo.ZFCFM_MCI_OTC002) AS a
GROUP BY  a.Date
order by date asc

select date, sum(PL) as [Value] from
(
SELECT  CAST(invDate AS DATE) AS Date,
 CAST(invNpvDiff  AS numeric(28, 1)) as [PL] from dbo.ZFCFM_MCI_OTC002) a
 group by date
 order by date desc


select a.date, a.value as [SwapPL], isnull(b.value,0) as [BidAskPL]
from hedgeos.dbo.SwapPnl_view A left outer join hedgeos.dbo.bidaskPnl_view B on a.date = b.date
where a.date = '2021-09-30'