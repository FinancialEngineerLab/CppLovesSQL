
SELECT * FROM (
	SELECT
	b.JobSetId
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView A inner join HanwhaComputations.dbo.job B on a.ticketid = b.TicketId
										inner join  hanwhainput.dbo.Schedule C on a.RecordId = c.POLY_NO
	WHERE a.TicketId IN (
'13115',
'13114',
'13113',
'13112',
'13111',
'13110',
'13085',
'13084',
'13083',
'13082',
'13081',
'13080'
	)
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
		and c.EntryDate<='2021-10-20'
		and c.CLOG_YM ='202108'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN (
[PV],
[DELTA],
[RHO.3M],[RHO.1Y],[RHO.2Y],[RHO.3Y],[RHO.4Y],[RHO.5Y],[RHO.7Y],[RHO.10Y],[RHO.12Y],[RHO.15Y],[RHO.20Y])) AS PIVOT_RESULT order by JobSetId asc



SELECT * FROM (
	SELECT
	b.JobSetId
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView A inner join HanwhaComputations.dbo.job B on a.ticketid = b.TicketId
	WHERE a.TicketId IN (
'13115',
'13114',
'13113',
'13112',
'13111',
'13110',
'13085',
'13084',
'13083',
'13082',
'13081',
'13080'
	)
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
		and RecordId in (select POLY_NO from hanwhainput.dbo.Schedule where CLOG_YM ='202108' and EntryDate <= '2021-10-20')
		
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN (
[PV],
[DELTA],
[RHO.3M],[RHO.1Y],[RHO.2Y],[RHO.3Y],[RHO.4Y],[RHO.5Y],[RHO.7Y],[RHO.10Y],[RHO.12Y],[RHO.15Y],[RHO.20Y])) AS PIVOT_RESULT order by JobSetId asc
