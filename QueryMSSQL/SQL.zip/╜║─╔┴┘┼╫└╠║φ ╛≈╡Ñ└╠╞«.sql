
select * from hanwhainput.dbo.Schedule where clog_ym ='202110'
541892
/* ���� ��ȸ
irkd_code_dtal	entrydate
1761	2019-12-02
1798	2019-12-02
1769	2019-12-02
1791	2019-12-02
1918	2021-02-01
1736	2021-02-01
1828	2021-02-16
1652	2021-02-17
1836	2021-02-17
1659	2021-02-17
1274	2021-02-17
1612	2021-02-17
1802	2021-02-17
1275	2021-02-17
1270	NULL
1795	NULL
1688	NULL
1613	NULL
1685	NULL
1610	NULL
1710	NULL
1609	NULL
*/

insert into hanwhainput.dbo.TB_ST1MV01V_EXPT_BAS_MAIN select * from hanwha3input.dbo.TB_ST1MV01V_2107_EXPT_BAS_MAIN where clog_ym ='202107'
insert into hanwhainput.dbo.TB_ST1MV01V_EXPT_BAS_MAIN select * from hanwha3input.dbo.TB_ST1MV01V_2107_EXPT_BAS_MAIN2 where clog_ym ='202107'

insert into hanwhainput.dbo.TB_ST1MV01V_EXPT_BAS_MAIN2 select * from hanwha3input.dbo.TB_ST1MV01V_2107_EXPT_BAS_MAIN2 where clog_ym ='202107'


select * from hanwhainput.dbo.TB_ST1MV01V_EXPT_BAS_MAIN where clog_ym ='202106'

select * from hanwhainput.dbo.TB_ST1MV01V_EXPT_BAS_MAIN2 where clog_ym ='202106'


22616+
select * from hanwha3input.dbo.TB_ST1MV01V_2110_EXPT_BAS_MAIN where clog_ym ='202110'
select * from hanwha3input.dbo.TB_ST1MV01V_2110_EXPT_BAS_MAIN2 where clog_ym ='202110'
select * from hanwha3input.dbo.TB_ST1MV01V_2110_EXPT_BAS_MAIN


-- 1�ܰ� �ֱ� --
-- 22616
insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2019-12-02'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN
where IRKD_CODE_DTAL in (
'1761',
'1798',
'1769',
'1791')

-- 2�ܰ�ֱ�
-- 2/1 : 53888
insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-02-01'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1918','1736')

-- 2/16 : 16185

insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-02-16'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1828')

-- 2/17: 97134

insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-02-17'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1652',
'1836',
'1659',
'1274',
'1612',
'1802',
'1275')



insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-07-19'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1795')


insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-07-20'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1270') and poly_no%3 = 0

insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-09-14'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1270') and poly_no%3 = 1

insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-09-15'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1270') and poly_no%3 = 2




insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-09-16'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1610') and poly_no%2 = 0


insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-09-17'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1610') and poly_no%2 = 1


insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-09-23'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1688') and poly_no%2 = 0
insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-09-24'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1688') and poly_no%2 = 1

(11254�� ���� ������ ����)

(11335�� ���� ������ ����)

(11388�� ���� ������ ����)


insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-09-27'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1710') and poly_no%3 = 0

insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-09-28'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1710') and poly_no%3 = 1

insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-09-29'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1710') and poly_no%3 = 2



insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-10-05'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1613') and poly_no%5= 0
insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-10-06'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1613') and poly_no%5= 1
insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-10-07'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1613') and poly_no%5= 2
insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-10-08'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1613') and poly_no%5= 3
insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-10-12'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1613') and poly_no%5= 4


insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-10-13'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1609') and poly_no%12= 0
insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-10-14'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1609') and poly_no%12= 1
insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-10-15'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1609') and poly_no%12= 2
insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-10-18'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1609') and poly_no%12= 3
insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-10-19'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1609') and poly_no%12= 4
insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-10-20'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1609') and poly_no%12= 5
insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-10-21'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1609') and poly_no%12= 6
insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-10-22'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1609') and poly_no%12= 7
insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-10-25'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1609') and poly_no%12= 8
insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-10-26'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1609') and poly_no%12= 9
insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-10-22'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1609') and poly_no%12= 10
insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-10-28'as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1609') and poly_no%12= 11





-- not yet: 221747
insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, NULL as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2111_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1685')
























delete hanwhainput.dbo.schedule where IRKD_CODE_DTAL = '1270' and CLOG_YM ='202107'

15564

insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, '2021-07-19' as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2107_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1795')


insert into hanwhainput.dbo.schedule
select clog_ym, poly_no, HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, NULL as [EntryDate] from Hanwha3Input.dbo.TB_ST1MV01V_2107_EXPT_BAS_MAIN2
where IRKD_CODE_DTAL in (
'1270') and POLY_NO % 3 <> 0
5327
10237
select distinct irkd_code_dtal, entrydate from hanwhainput.dbo.Schedule where clog_ym ='202104'

select distinct(irkd_code_dtal)  from hanwhainput.dbo.Schedule where clog_ym ='202104'

select * from hanwhainput.dbo.TB_ST1MV01V_EXPT_BAS_MAIN where clog_ym ='202103'


--insert into hanwhainput.dbo.schedule select '202103' , dajflkadjfllkf form where 


(23004�� ���� ������ ����)

(55194�� ���� ������ ����)

(16706�� ���� ������ ����)

(99963�� ���� ������ ����)

(355285�� ���� ������ ����)




select '202103' as [CLOG_YM], a.poly_no as [POLY_NO], a.hedg_blok_dvsn as [HEDG_BLOK_DVSN], a.irkd_code_dtal as [IRKD_CODE_DTAL], ISNULL(a.irkd_code_item, NULL) as [IRKD_CODE_ITEM], B.entryDate as [EntryDate] 
from hanwhainput.dbo.TB_ST1MV01V_EXPT_BAS A right outer join hanwhainput.dbo.Schedule B on A.poly_no = B.POLY_NO
where
A.clog_ym = '202103'
and a.irkd_code_dtal in (
'1710',
'1274',
'1652',
'1275',
'1836',
'1798',
'1610',
'1609',
'1612',
'1828',
'1918',
'1769',
'1761',
'1659',
'1688',
'1613',
'1270',
'1791',
'1736',
'1802',
'1795',
'1685')
order by EntryDate desc

-- right : 608327
-- left : 608552