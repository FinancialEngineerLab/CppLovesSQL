/*** ������� 3���� �ٲ�� �� ***/


/****** ���� ******/
SELECT A.CLOG_YM 
     , A.HEDG_BLOK_DVSN
	 , COUNT(A.POLY_NO) as COUNT
	-- , SUM(A.SAV) AS SAV
	 , SUM(A.SAV_ORIGN) AS SAV_ORIGN
FROM
    (SELECT CLOG_YM 
         , HEDG_BLOK_DVSN
		 --, 'HEDGE_TYPE' = CASE WHEN FUND_CODE_01 = 'V9101' THEN '1_Vfund' ELSE HEDG_BLOK_DVSN END
	     , POLY_NO
	     , (BAS_VRF - BASC_LOAN) + (ADD_VRF - ADDC_LOAN) AS SAV
		 , (BAS_VRF + ADD_VRF) AS SAV_ORIGN
    FROM [HanwhaInput].[dbo].[TB_ST1MV01V_EXPT_BAS] where CLOG_YM = '202109') A
GROUP BY A.CLOG_YM, A.HEDG_BLOK_DVSN order by HEDG_BLOK_DVSN asc
;



/****** ����(�÷���UP����) ******/
SELECT A.CLOG_YM 
     --, A.HEDG_BLOK_DVSN
	 , A.HEDGE_TYPE
	 , COUNT(A.POLY_NO) as COUNT
	 , SUM(A.SAV) AS SAV
	 , SUM(A.SAV_ORIGN) AS SAV_ORIGN
FROM
    (SELECT CLOG_YM 
         , HEDG_BLOK_DVSN
		 , 'HEDGE_TYPE' = CASE WHEN FUND_CODE_01 = 'V9101' THEN '1_Vfund' ELSE HEDG_BLOK_DVSN END
	     , POLY_NO
	     , (BAS_VRF - BASC_LOAN) + (ADD_VRF - ADDC_LOAN) AS SAV
		 , (BAS_VRF + ADD_VRF) AS SAV_ORIGN
    FROM [HanwhaInput].[dbo].[TB_ST1MV01V_EXPT_BAS] where CLOG_YM = '202109') A
GROUP BY A.CLOG_YM, A.HEDGE_TYPE order by HEDGE_TYPE asc
;

/****** ������� ******/

SELECT A.CLOG_YM 
     , A.HEDG_BLOK_DVSN
	 , COUNT(A.POLY_NO) as COUNT
	 --, SUM(A.SAV) AS SAV
	 , SUM(A.SAV_ORIGN) AS SAV_ORIGN
FROM
    (SELECT B.CLOG_YM 
         , B.HEDG_BLOK_DVSN
		 --, 'HEDGE_TYPE' = CASE WHEN FUND_CODE_01 = 'V9101' THEN '1_Vfund' ELSE HEDG_BLOK_DVSN END
	     , C.POLY_NO
	     , (BAS_VRF - BASC_LOAN) + (ADD_VRF - ADDC_LOAN) AS SAV
		 , (BAS_VRF + ADD_VRF) AS SAV_ORIGN
    FROM [HanwhaInput].[dbo].[TB_ST1MV01V_EXPT_BAS] B inner join hanwhainput.dbo.Schedule C on B.POLY_NO = C.POLY_NO
	WHERE C.EntryDate <= '2021-10-30' and C.CLOG_YM = '202109'						
) A where a.CLOG_YM ='202109'
GROUP BY A.CLOG_YM, A.HEDG_BLOK_DVSN
;





---
SELECT A.CLOG_YM 
     , A.HEDG_BLOK_DVSN
	 , COUNT(A.POLY_NO) as COUNT
	 , SUM(A.SAV) AS SAV
	 , SUM(A.SAV_ORIGN) AS SAV_ORIGN
FROM
    (SELECT B.CLOG_YM 
         , B.HEDG_BLOK_DVSN
		 --, 'HEDGE_TYPE' = CASE WHEN FUND_CODE_01 = 'V9101' THEN '1_Vfund' ELSE HEDG_BLOK_DVSN END
	     , C.POLY_NO
	     , (BAS_VRF - BASC_LOAN) + (ADD_VRF - ADDC_LOAN) AS SAV
		 , (BAS_VRF + ADD_VRF) AS SAV_ORIGN
    FROM [HanwhaInput].[dbo].[TB_ST1MV01V_EXPT_BAS] B inner join hanwhainput.dbo.Schedule C on B.POLY_NO = C.POLY_NO
	WHERE C.EntryDate <= '2021-07-20' and C.CLOG_YM = '202107'
								and B.IRKD_CODE_DTAL in (
'1828',
'1270',
'1761',
'1769',
'1802',
'1836',
'1612',
'1736',
'1798',
'1274',
'1275',
'1791',
'1795',
'1652',
'1918',
'1659')
) A where a.CLOG_YM ='202107'
GROUP BY A.CLOG_YM, A.HEDG_BLOK_DVSN
;
---
SELECT A.CLOG_YM 
     , A.HEDG_BLOK_DVSN
	 , COUNT(A.POLY_NO) as COUNT
	 , SUM(A.SAV) AS SAV
	 , SUM(A.SAV_ORIGN) AS SAV_ORIGN
FROM
    (SELECT CLOG_YM 
         , HEDG_BLOK_DVSN
		 --, 'HEDGE_TYPE' = CASE WHEN FUND_CODE_01 = 'V9101' THEN '1_Vfund' ELSE HEDG_BLOK_DVSN END
	     , POLY_NO
	     , (BAS_VRF - BASC_LOAN) + (ADD_VRF - ADDC_LOAN) AS SAV
		 , (BAS_VRF + ADD_VRF) AS SAV_ORIGN
    FROM [HanwhaInput].[dbo].[TB_ST1MV01V_EXPT_BAS] WHERE POLY_NO in
		(select POLY_NO from hanwhainput.dbo.Schedule
						where EntryDate <='2021-07-20') and CLOG_YM = '202107'
								and IRKD_CODE_DTAL in (select distinct(irkd_code_dtal) from hanwhainput.dbo.schedule where entrydate<= '2021-07-20')
) A
GROUP BY A.CLOG_YM, A.HEDG_BLOK_DVSN
;




SELECT A.CLOG_YM 
     --, A.HEDG_BLOK_DVSN
	 , A.HEDGE_TYPE
	 , COUNT(A.POLY_NO) as COUNT
	 , SUM(A.SAV) AS SAV
	 , SUM(A.SAV_ORIGN) AS SAV_ORIGN
FROM
    (SELECT CLOG_YM 
         , HEDG_BLOK_DVSN
		 , 'HEDGE_TYPE' = CASE WHEN FUND_CODE_01 = 'V9101' THEN '1_Vfund' ELSE HEDG_BLOK_DVSN END
	     , POLY_NO
	     , (BAS_VRF - BASC_LOAN) + (ADD_VRF - ADDC_LOAN) AS SAV
		 , (BAS_VRF + ADD_VRF) AS SAV_ORIGN
    FROM [HanwhaInput].[dbo].TB_ST1MV01V_EXPT_BAS_MAIN where CLOG_YM = '202107') A
GROUP BY A.CLOG_YM, A.HEDGE_TYPE order by HEDGE_TYPE asc
;
/****** ����(�÷���UP����) ******/
SELECT A.CLOG_YM 
     --, A.HEDG_BLOK_DVSN
	 , A.HEDGE_TYPE
	 , COUNT(A.POLY_NO) as COUNT
	 , SUM(A.SAV) AS SAV
	 , SUM(A.SAV_ORIGN) AS SAV_ORIGN
FROM
    (SELECT CLOG_YM 
         , HEDG_BLOK_DVSN
		 , 'HEDGE_TYPE' = CASE WHEN FUND_CODE_01 = 'V9101' THEN '1_Vfund' ELSE HEDG_BLOK_DVSN END
	     , POLY_NO
	     , (BAS_VRF - BASC_LOAN) + (ADD_VRF - ADDC_LOAN) AS SAV
		 , (BAS_VRF + ADD_VRF) AS SAV_ORIGN
    FROM [HanwhaInput].[dbo].[TB_ST1MV01V_EXPT_BAS] where CLOG_YM = '202107') A
GROUP BY A.CLOG_YM, A.HEDGE_TYPE order by HEDGE_TYPE asc


SELECT A.CLOG_YM 
     , A.HEDG_BLOK_DVSN
	 , COUNT(A.POLY_NO) as COUNT
	 , SUM(A.SAV) AS SAV
	 , SUM(A.SAV_ORIGN) AS SAV_ORIGN
FROM
    (SELECT CLOG_YM 
         , HEDG_BLOK_DVSN
		 --, 'HEDGE_TYPE' = CASE WHEN FUND_CODE_01 = 'V9101' THEN '1_Vfund' ELSE HEDG_BLOK_DVSN END
	     , POLY_NO
	     , (BAS_VRF - BASC_LOAN) + (ADD_VRF - ADDC_LOAN) AS SAV
		 , (BAS_VRF + ADD_VRF) AS SAV_ORIGN
    FROM [HanwhaInput].[dbo].[TB_ST1MV01V_EXPT_BAS]
	WHERE POLY_NO in (select POLY_NO from hanwhainput.dbo.TB_ST1MV01V_EXPT_BAS_MAIN where CLOG_YM ='202104')) A
GROUP BY A.CLOG_YM, A.HEDG_BLOK_DVSN ORDER BY HEDG_BLOK_DVSN ASC

/****** ����(�÷���UP����) ******/
SELECT A.CLOG_YM 
     --, A.HEDG_BLOK_DVSN
	 , A.HEDGE_TYPE
	 , COUNT(A.POLY_NO) as COUNT
	 , SUM(A.SAV) AS SAV
	 , SUM(A.SAV_ORIGN) AS SAV_ORIGN
FROM
    (SELECT CLOG_YM 
         , HEDG_BLOK_DVSN
		 , 'HEDGE_TYPE' = CASE WHEN FUND_CODE_01 = 'V9101' THEN '1_Vfund' ELSE HEDG_BLOK_DVSN END
	     , POLY_NO
	     , (BAS_VRF - BASC_LOAN) + (ADD_VRF - ADDC_LOAN) AS SAV
		 , (BAS_VRF + ADD_VRF) AS SAV_ORIGN
    FROM [HanwhaInput].[dbo].TB_ST1MV01V_EXPT_BAS_MAIN where CLOG_YM = '202107') A
GROUP BY A.CLOG_YM, A.HEDGE_TYPE order by HEDGE_TYPE asc
;

select * from hanwhainput.dbo.TB_ST1MV01V_EXPT_BAS A inner join hanwhainput.dbo.TB_STEIP81M B on A.IRKD_CODE_DTAL = B.IRKD_CODE_DTAL
where A.clog_ym= '202012' and B.irkd_code_name like '%dex%'
;


select distinct(a.IRKD_CODE_DTAL) from hanwhainput.dbo.TB_ST1MV01V_EXPT_BAS A inner join hanwhainput.dbo.TB_STEIP81M B on A.IRKD_CODE_DTAL = B.IRKD_CODE_DTAL
where A.clog_ym= '202012' and B.irkd_code_name like '%dex%'




--------------------------------------------------------------------------------------------------------------
/****** ���� ����+���� ******/

s

Declare @date as date
set @date = '2021-05-31'

SELECT A.CLOG_YM 
     , A.HEDG_BLOK_DVSN
	 , COUNT(A.POLY_NO) as COUNT
	 , SUM(A.SAV) AS SAV
	 , SUM(A.SAV_ORIGN) AS SAV_ORIGN
FROM
    (SELECT CLOG_YM 
         , HEDG_BLOK_DVSN
		 --, 'HEDGE_TYPE' = CASE WHEN FUND_CODE_01 = 'V9101' THEN '1_Vfund' ELSE HEDG_BLOK_DVSN END
	     , POLY_NO
	     , (BAS_VRF - BASC_LOAN) + (ADD_VRF - ADDC_LOAN) AS SAV
		 , (BAS_VRF + ADD_VRF) AS SAV_ORIGN
    FROM [HanwhaInput].[dbo].[TB_ST1MV01V_EXPT_BAS]
	WHERE POLY_NO in (select POLY_NO from hanwhainput.dbo.TB_ST1MV01V_EXPT_BAS_MAIN where CLOG_YM ='202104')) A
GROUP BY A.CLOG_YM, A.HEDG_BLOK_DVSN
ORDER BY HEDG_BLOK_DVSN ASC

/****** ���� ���� ******/
Declare @date as date
set @date = '2021-02-17'
SELECT A.CLOG_YM
	 , B.IRKD_CODE_DTAL
     , A.HEDG_BLOK_DVSN
	 , COUNT(A.POLY_NO) as COUNT
	 , SUM(A.SAV) AS SAV
	 , SUM(A.SAV_ORIGN) AS SAV_ORIGN
	FROM
    (SELECT CLOG_YM 
         , HEDG_BLOK_DVSN
		 --, 'HEDGE_TYPE' = CASE WHEN FUND_CODE_01 = 'V9101' THEN '1_Vfund' ELSE HEDG_BLOK_DVSN END
	     , POLY_NO
	     , (BAS_VRF - BASC_LOAN) + (ADD_VRF - ADDC_LOAN) AS SAV
		 , (BAS_VRF + ADD_VRF) AS SAV_ORIGN
    FROM [HanwhaInput].[dbo].[TB_ST1MV01V_EXPT_BAS] WHERE POLY_NO in
		(select POLY_NO from hanwhainput.dbo.Schedule
						where EntryDate <=@date) and CLOG_YM = '202101'
								and IRKD_CODE_DTAL in 
													(select distinct(irkd_code_dtal)
													from hanwhainput.dbo.schedule
													where entrydate = @date)
	) A
	inner join hanwhainput.dbo.Schedule B
	on a.POLY_NO = B.POLY_NO 
	GROUP BY A.CLOG_YM, B.IRKD_CODE_DTAL, a.HEDG_BLOK_DVSN
;


/****** ���� ���� ******/
Declare @date as date
set @date = '2021-02-17'

SELECT A.CLOG_YM
	 , B.IRKD_CODE_DTAL
     , A.HEDG_BLOK_DVSN
	 , COUNT(A.POLY_NO) as COUNT
	 , SUM(A.SAV) AS SAV
	 , SUM(A.SAV_ORIGN) AS SAV_ORIGN
	FROM
    (SELECT CLOG_YM 
         , HEDG_BLOK_DVSN
		 --, 'HEDGE_TYPE' = CASE WHEN FUND_CODE_01 = 'V9101' THEN '1_Vfund' ELSE HEDG_BLOK_DVSN END
	     , POLY_NO
	     , (BAS_VRF - BASC_LOAN) + (ADD_VRF - ADDC_LOAN) AS SAV
		 , (BAS_VRF + ADD_VRF) AS SAV_ORIGN
    FROM [HanwhaInput].[dbo].[TB_ST1MV01V_EXPT_BAS] where clog_ym ='202101'
	) A
	inner join hanwhainput.dbo.TB_ST1MV01V_EXPT_BAS_MAIN B
	on a.POLY_NO = B.POLY_NO 
	where B.CLOG_YM ='202101'
	GROUP BY A.CLOG_YM, B.IRKD_CODE_DTAL, a.HEDG_BLOK_DVSN

-------------------------------------------------------------------------------------------------------------------------------------
/****** ����2�ܰ� ��ü ******/

select distinct(irkd_code_dtal) from hanwhainput.dbo.schedule where entrydate = '2021-02-17'

select * from HanwhaComputations.dbo.job where jobsetid like '%210216%'

---
SELECT A.CLOG_YM 
     , A.HEDG_BLOK_DVSN
	 , COUNT(A.POLY_NO) as COUNT
	 , SUM(A.SAV) AS SAV
	 , SUM(A.SAV_ORIGN) AS SAV_ORIGN
FROM
    (SELECT CLOG_YM 
         , HEDG_BLOK_DVSN
		 --, 'HEDGE_TYPE' = CASE WHEN FUND_CODE_01 = 'V9101' THEN '1_Vfund' ELSE HEDG_BLOK_DVSN END
	     , POLY_NO
	     , (BAS_VRF - BASC_LOAN) + (ADD_VRF - ADDC_LOAN) AS SAV
		 , (BAS_VRF + ADD_VRF) AS SAV_ORIGN
    FROM [HanwhaInput].[dbo].[TB_ST1MV01V_EXPT_BAS] WHERE POLY_NO in
		(select POLY_NO from hanwhainput.dbo.Schedule
						where EntryDate <='2021-02-17') and CLOG_YM = '202104'
								and IRKD_CODE_DTAL in (select distinct(irkd_code_dtal) from hanwhainput.dbo.schedule where entrydate = '2021-02-17')
) A
GROUP BY A.CLOG_YM, A.HEDG_BLOK_DVSN
;


SELECT A.CLOG_YM
	 , B.IRKD_CODE_DTAL
     , A.HEDG_BLOK_DVSN
	 , COUNT(A.POLY_NO) as COUNT
	 , SUM(A.SAV) AS SAV
	 , SUM(A.SAV_ORIGN) AS SAV_ORIGN
FROM
    (SELECT CLOG_YM 
         , HEDG_BLOK_DVSN
		 --, 'HEDGE_TYPE' = CASE WHEN FUND_CODE_01 = 'V9101' THEN '1_Vfund' ELSE HEDG_BLOK_DVSN END
	     , POLY_NO
	     , (BAS_VRF - BASC_LOAN) + (ADD_VRF - ADDC_LOAN) AS SAV
		 , (BAS_VRF + ADD_VRF) AS SAV_ORIGN
    FROM [HanwhaInput].[dbo].[TB_ST1MV01V_EXPT_BAS] WHERE POLY_NO in
		(select POLY_NO from hanwhainput.dbo.Schedule
						where EntryDate <='2021-02-17') and CLOG_YM = '202012'
								and IRKD_CODE_DTAL in (select distinct(irkd_code_dtal) from hanwhainput.dbo.schedule where entrydate = '2021-02-17')
) A inner join hanwhainput.dbo.Schedule B on a.POLY_NO = B.POLY_NO 
GROUP BY A.CLOG_YM, B.IRKD_CODE_DTAL, a.HEDG_BLOK_DVSN
;
/****** ����2�ܰ� ******/
SELECT A.CLOG_YM 
     , A.HEDG_BLOK_DVSN
	 , COUNT(A.POLY_NO) as COUNT
	 , SUM(A.SAV) AS SAV
	 , SUM(A.SAV_ORIGN) AS SAV_ORIGN
FROM
    (SELECT CLOG_YM 
         , HEDG_BLOK_DVSN
		 --, 'HEDGE_TYPE' = CASE WHEN FUND_CODE_01 = 'V9101' THEN '1_Vfund' ELSE HEDG_BLOK_DVSN END
	     , POLY_NO
	     , (BAS_VRF - BASC_LOAN) + (ADD_VRF - ADDC_LOAN) AS SAV
		 , (BAS_VRF + ADD_VRF) AS SAV_ORIGN
    FROM [HanwhaInput].[dbo].[TB_ST1MV01V_EXPT_BAS] WHERE POLY_NO in (select POLY_NO from hanwhainput.dbo.Schedule where EntryDate <='2021-02-01') and CLOG_YM = '202012' and IRKD_CODE_DTAL = '1918') A
GROUP BY A.CLOG_YM, A.HEDG_BLOK_DVSN
;
/*
;
/*
/****** SAMPLE ******/
SELECT A.CLOG_YM 
     , A.HEDGE_TYPE
	 , COUNT(A.POLY_NO) as COUNT
	 , SUM(A.SAV) AS SAV
FROM
    (SELECT CLOG_YM 
         , 'HEDGE_TYPE' = CASE WHEN FUND_CODE_01 = 'V9101' THEN '1_Vfund' ELSE HEDG_BLOK_DVSN END
	     , POLY_NO
	     , (BAS_VRF - BASC_LOAN) + (ADD_VRF - ADDC_LOAN) AS SAV
    FROM [HanwhaInput].[dbo].[TB_ST1MV01V_1909_SAMPLE_5_NP]) A
GROUP BY A.CLOG_YM, A.HEDGE_TYPE
;

/****** �Ⱥ� ******/
SELECT A.CLOG_YM 
     , A.HEDGE_TYPE
	 , COUNT(A.POLY_NO) as COUNT
	 , SUM(A.SAV) AS SAV
	 , A.PROPOSAL
FROM
    (SELECT I.CLOG_YM 
          , 'HEDGE_TYPE' = CASE WHEN I.FUND_CODE_01 = 'V9101' THEN '1_Vfund' ELSE I.HEDG_BLOK_DVSN END
	      , I.POLY_NO
	      , (I.BAS_VRF - I.BASC_LOAN) + (I.ADD_VRF - I.ADDC_LOAN) AS SAV
		  , S.PROPOSAL
     FROM [HanwhaInput].[dbo].[TB_ST1MV01V_1909_SAMPLE_5_NP] I
	      inner join HanwhaInput.dbo.Sample_Proposal_1909_56 S on I.POLY_NO = S.POLY_NO) A
GROUP BY A.CLOG_YM, A.HEDGE_TYPE, A.PROPOSAL
;


/*
/****** ����10% ******/
SELECT A.CLOG_YM 
     , A.HEDGE_TYPE
	 , COUNT(A.POLY_NO) as COUNT
	 , SUM(A.SAV) AS SAV
FROM
    (SELECT CLOG_YM 
         , 'HEDGE_TYPE' = CASE WHEN FUND_CODE_01 = 'V9101' THEN '1_Vfund' ELSE HEDG_BLOK_DVSN END
	     , POLY_NO
	     , (BAS_VRF - BASC_LOAN) + (ADD_VRF - ADDC_LOAN) AS SAV
    FROM [HanwhaInput].[dbo].[TB_ST1MV01V_1909_SAMPLE_5_NP]
    WHERE POLY_NO IN
         (SELECT X.POLY_NO
          FROM (SELECT  HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, POLY_NO, N = ROW_NUMBER() OVER (PARTITION BY HEDG_BLOK_DVSN, IRKD_CODE_DTAL, 
                                        IRKD_CODE_ITEM
                         ORDER BY RAND(POLY_NO))
          FROM     HanwhaInput.dbo.TB_ST1MV01V_1905_SAMPLE
          GROUP BY HEDG_BLOK_DVSN, IRKD_CODE_DTAL, IRKD_CODE_ITEM, POLY_NO
          ) X
          WHERE  X. N % 10 = 0)
) A
GROUP BY A.CLOG_YM, A.HEDGE_TYPE
*/
*/