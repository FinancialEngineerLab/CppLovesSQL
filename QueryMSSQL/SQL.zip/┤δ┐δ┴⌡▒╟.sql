
SELECT * FROM (
	SELECT A.TicketId
	, b.JobName
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView A inner join HanwhaComputations.dbo.job B on A.TicketId = B.TicketId
	WHERE A.TicketId IN (
'13713',
'13712',
'13710',
'13709',
'13708'
)
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN (
[PV],
[DELTA],[GAMMA],
[RHO.3M],[RHO.1Y],[RHO.2Y],[RHO.3Y],[RHO.4Y],[RHO.5Y],[RHO.7Y],[RHO.10Y],[RHO.12Y],[RHO.15Y],[RHO.20Y]
)
) AS PIVOT_RESULT-- order by ticketid asc

SELECT * from HanwhaComputations.dbo.MarkView where ticketid= '13717'
