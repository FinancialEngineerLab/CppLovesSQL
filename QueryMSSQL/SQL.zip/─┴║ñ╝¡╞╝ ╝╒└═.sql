select * from hedgeos.dbo.Greeks_IR_Convexity where date in('2021-07-01', '2021-07-12','2021-07-30','2021-08-06','2021-08-20','2021-09-02','2021-09-13','2021-09-27')

select * from hedgeos.dbo.THistoryQuote where tradeday in('2021-07-01', '2021-07-12','2021-07-30','2021-08-06','2021-08-20','2021-09-02','2021-09-13','2021-09-27')

select * from hedgeos.dbo.THistoryQuote where tradeday >= '2021-07-01'



select a.Tradeday,b.Date, ric, adjRho, Convexity, value  from hedgeos.dbo.THistoryQuote a  inner join hedgeos.dbo.Greeks_IR_Convexity_internal b  on a.Tradeday = b.Date
where a.Tradeday in ('2021-07-01', '2021-07-12','2021-07-30','2021-08-06','2021-08-20','2021-09-02','2021-09-13','2021-09-27')
and ric = tenor


update hedgeos.dbo.Greeks_IR_Convexity_internal set adjRho = convexity*value*10000 + c.[12Y]
from  hedgeos.dbo.THistoryQuote a inner join hedgeos.dbo.Greeks_IR_Convexity_internal b  on a.Tradeday = b.Date
inner join hedgeos.dbo.Greeks_IR_prev_Liability_View c on hedgeos.dbo.fnPrevWorkDay(a.Tradeday) = c.date
where ric = tenor and ric='12Y' and c.Date = hedgeos.dbo.fnPrevWorkDay(a.Tradeday)

update hedgeos.dbo.Greeks_IR_Convexity_internal set adjRho = convexity*value*10000 +c.[15Y]
from  hedgeos.dbo.THistoryQuote a inner join hedgeos.dbo.Greeks_IR_Convexity_internal b  on a.Tradeday = b.Date
inner join hedgeos.dbo.Greeks_IR_prev_Liability_View c on hedgeos.dbo.fnPrevWorkDay(a.Tradeday) = c.date
where ric = tenor and ric='15Y' and c.Date = hedgeos.dbo.fnPrevWorkDay(a.Tradeday)


update hedgeos.dbo.Greeks_IR_Convexity_internal set adjRho = convexity*value*10000 + c.[20Y]
from  hedgeos.dbo.THistoryQuote a inner join hedgeos.dbo.Greeks_IR_Convexity_internal b  on a.Tradeday = b.Date
inner join hedgeos.dbo.Greeks_IR_prev_Liability_View c on hedgeos.dbo.fnPrevWorkDay(a.Tradeday) = c.date
where ric = tenor and ric='20Y' and c.Date = hedgeos.dbo.fnPrevWorkDay(a.Tradeday)




update hedgeos.dbo.Greeks_IR_Convexity set adjRho = convexity*value*10000 + c.[15Y]
from  hedgeos.dbo.THistoryQuote a inner join hedgeos.dbo.Greeks_IR_Convexity b  on a.Tradeday = b.Date
inner join hedgeos.dbo.Greeks_IR_prev_Liability_View c on hedgeos.dbo.fnPrevWorkDay(a.Tradeday) = c.date
where a.Tradeday in ('2021-07-01', '2021-07-12','2021-07-30','2021-08-06','2021-08-20','2021-09-02','2021-09-13','2021-09-27')
and ric = tenor and ric='15Y' and c.Date = hedgeos.dbo.fnPrevWorkDay(a.Tradeday)



update hedgeos.dbo.Greeks_IR_Convexity set adjRho = convexity*value*10000 + c.[20Y]
from  hedgeos.dbo.THistoryQuote a inner join hedgeos.dbo.Greeks_IR_Convexity b  on a.Tradeday = b.Date
inner join hedgeos.dbo.Greeks_IR_prev_Liability_View c on hedgeos.dbo.fnPrevWorkDay(a.Tradeday) = c.date
where a.Tradeday in ('2021-07-01', '2021-07-12','2021-07-30','2021-08-06','2021-08-20','2021-09-02','2021-09-13','2021-09-27')
and ric = tenor and ric='20Y' and c.Date = hedgeos.dbo.fnPrevWorkDay(a.Tradeday)

select date, a.Tradeday, ric, adjRho, Convexity, value  from hedgeos.dbo.THistoryQuote a  inner join hedgeos.dbo.Greeks_IR_Convexity b  on a.Tradeday = b.Date
where Date = '2021-07-01' 
and ric = tenor