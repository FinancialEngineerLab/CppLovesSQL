

select * from HanwhaComputations.dbo.Job order by StartAt desc


upda

select * from HanwhaComputations.dbo.pricingfailure order by timestamp desc
select * from HanwhaComputations.dbo.Job order by StartAt desc
select * from HanwhaComputations.dbo.job where ValuationDate = '2020-11-30' order by startat desc
select * from HanwhaComputations.dbo.flow where ProductNameId = '196' and cashflowdate = '2020-12-01'

--type2 
select * from HanwhaComputations.dbo.flowview where ticketid = '9'
--type1
select * from HanwhaComputations.dbo.flowview where ticketid = '10'


-- KTB - IRS Multi Curve --

select * from hanwhacomputations.dbo.job where jobname like '%Type1_SW_ALL%' order by ValuationDate desc

update HanwhaComputations.dbo.job set jobsetid = '001' where ticketid in 
(
'13408',
'13407',
'13406',
'13405',
'13404',
'13403',
'13402',
'13401')
update HanwhaComputations.dbo.job set jobsetid = '210119891' where ticketid = '5169'
update HanwhaComputations.dbo.job set jobsetid = '210118891' where ticketid = '5154'
update HanwhaComputations.dbo.job set jobsetid = '210115891' where ticketid = '5137'
select * from HanwhaComputations.dbo.Job where valuationdate = '2021-01-20' and jobname like '%Type1%' order by StartAt desc 

select * from HanwhaComputations.dbo.Job where valuationdate = '2020-12-31' and jobname like '%Type6%' order by StartAt desc 
select * from HanwhaComputations.dbo.Job where valuationdate = '2020-12-31' and jobname like '%Type3%' order by StartAt desc 

select * from hanwhacomputations.dbo.job where ticketid = '5452' or ticketid = '5451'or ticketid = '5450' or ticketid = '5449'or ticketid = '5443'or ticketid = '5471'
or ticketid = '5442'
or ticketid = '4379'
or ticketid = '4380'
or ticketid = '4381'
or ticketid = '4382'
or ticketid = '4383'
or ticketid = '4384'
or ticketid = '4385'

select * from Hanwha2Computations.dbo.Job order by StartAt desc


SELECT * FROM (
	SELECT A.TicketId
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView A inner join HanwhaComputations.dbo.job B on A.TicketId = B.TicketId
	WHERE A.TicketId IN (
'9104',
'9103',
'9102',
'9101',
'9100',
'9099',
'9098'
)
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN (
[PV],
[DELTA],[GAMMA],
[RHO.3M],[RHO.1Y],[RHO.2Y],[RHO.3Y],[RHO.4Y],[RHO.5Y],[RHO.7Y],[RHO.10Y],[RHO.12Y],[RHO.15Y],[RHO.20Y]
)
) AS PIVOT_RESULT-- order by ticketid asc

--

SELECT * FROM (
	SELECT TicketId
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView 
	WHERE TicketId IN (
'7575' ,'7044','6830','7578'
	)
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN (
[PV],
[DELTA],[GAMMA],
[RHO.3M],[RHO.1Y],[RHO.2Y],[RHO.3Y],[RHO.4Y],[RHO.5Y],[RHO.7Y],[RHO.10Y],[RHO.12Y],[RHO.15Y],[RHO.20Y],
[CONVEXITY.3M],[CONVEXITY.1Y],[CONVEXITY.2Y],[CONVEXITY.3Y],[CONVEXITY.4Y],[CONVEXITY.5Y],[CONVEXITY.7Y],[CONVEXITY.10Y],[CONVEXITY.12Y],[CONVEXITY.15Y],[CONVEXITY.20Y])
) AS PIVOT_RESULT-- order by ticketid asc




SELECT * FROM (
	SELECT TicketId
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView A
	WHERE TicketId IN ('5137','5214','5154','5215', '5169','5216', '5196','5212')
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
		and RecordId  in (select b.poly_no from hanwhainput.dbo.schedule where entrydate <= '2021-02-01')
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN (
[PV],
[DELTA],[GAMMA],
[RHO.3M],[RHO.1Y],[RHO.2Y],[RHO.3Y],[RHO.4Y],[RHO.5Y],[RHO.7Y],[RHO.10Y],[RHO.12Y],[RHO.15Y],[RHO.20Y],
[CONVEXITY.3M],[CONVEXITY.1Y],[CONVEXITY.2Y],[CONVEXITY.3Y],[CONVEXITY.4Y],[CONVEXITY.5Y],[CONVEXITY.7Y],[CONVEXITY.10Y],[CONVEXITY.12Y],[CONVEXITY.15Y],[CONVEXITY.20Y])
) AS PIVOT_RESULT-- order by ticketid asc


-- KTB - IRS Multi Curve --

SELECT * FROM (
	SELECT TicketId
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView 
	WHERE TicketId IN ('2961','2962', '2963', '2964', '2965', '2966', '2967')
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN (
[PV],
[DELTA],[GAMMA],
[RHO.3M],[RHO.1Y],[RHO.2Y],[RHO.3Y],[RHO.4Y],[RHO.5Y],[RHO.7Y],[RHO.10Y],[RHO.12Y],[RHO.15Y],[RHO.20Y],
[CONVEXITY.3M],[CONVEXITY.1Y],[CONVEXITY.2Y],[CONVEXITY.3Y],[CONVEXITY.4Y],[CONVEXITY.5Y],[CONVEXITY.7Y],[CONVEXITY.10Y],[CONVEXITY.12Y],[CONVEXITY.15Y],[CONVEXITY.20Y])
) AS PIVOT_RESULT order by ticketid asc


-- 9���� --
select * from HanwhaComputations.dbo.Job where valuationDate = '2020-09-29' and statuscode = '1' and ProjectionName  like '%200929%' and recordsfailed = '0' order by StartAt desc

SELECT * FROM (
	SELECT TicketId
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView 
	WHERE TicketId IN ('2284','2285', '2286', '2287', '2290', '2288', '2289')
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN (
[PV],
[DELTA],[GAMMA],
[RHO.3M],[RHO.1Y],[RHO.2Y],[RHO.3Y],[RHO.4Y],[RHO.5Y],[RHO.7Y],[RHO.10Y],[RHO.12Y],[RHO.15Y],[RHO.20Y],
[CONVEXITY.3M],[CONVEXITY.1Y],[CONVEXITY.2Y],[CONVEXITY.3Y],[CONVEXITY.4Y],[CONVEXITY.5Y],[CONVEXITY.7Y],[CONVEXITY.10Y],[CONVEXITY.12Y],[CONVEXITY.15Y],[CONVEXITY.20Y])
) AS PIVOT_RESULT order by ticketid asc


select * from HanwhaComputations.dbo.Job order by StartAt desc
select * from HanwhaComputations.dbo.Markview


SELECT * FROM (
	SELECT TicketId
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView 
	WHERE TicketId IN ('2837','2838', '2839', '2840', ' 2841', ' 2842', ' 2843')
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN (
[PV],
[DELTA],[GAMMA],
[RHO.3M],[RHO.1Y],[RHO.2Y],[RHO.3Y],[RHO.4Y],[RHO.5Y],[RHO.7Y],[RHO.10Y],[RHO.12Y],[RHO.15Y],[RHO.20Y],
[CONVEXITY.3M],[CONVEXITY.1Y],[CONVEXITY.2Y],[CONVEXITY.3Y],[CONVEXITY.4Y],[CONVEXITY.5Y],[CONVEXITY.7Y],[CONVEXITY.10Y],[CONVEXITY.12Y],[CONVEXITY.15Y],[CONVEXITY.20Y])
) AS PIVOT_RESULT order by ticketid asc




SELECT * FROM (
	SELECT TicketId
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView 
	WHERE TicketId IN ('2824','2825', '2826', '2836', ' 2828', ' 2829', ' 2830')
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN (
[PV],
[DELTA],[GAMMA],
[RHO.3M],[RHO.1Y],[RHO.2Y],[RHO.3Y],[RHO.4Y],[RHO.5Y],[RHO.7Y],[RHO.10Y],[RHO.12Y],[RHO.15Y],[RHO.20Y],
[CONVEXITY.3M],[CONVEXITY.1Y],[CONVEXITY.2Y],[CONVEXITY.3Y],[CONVEXITY.4Y],[CONVEXITY.5Y],[CONVEXITY.7Y],[CONVEXITY.10Y],[CONVEXITY.12Y],[CONVEXITY.15Y],[CONVEXITY.20Y])
) AS PIVOT_RESULT order by ticketid asc





-- 9���� --
select * from HanwhaComputations.dbo.Job where valuationDate = '2020-09-29' and statuscode = '1' and ProjectionName  like '%200929%' and recordsfailed = '0' order by StartAt desc

SELECT * FROM (
	SELECT TicketId
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView 
	WHERE TicketId IN ('2284','2285', '2286', '2287', '2290', '2288', '2289')
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN (
[PV],
[DELTA],[GAMMA],
[RHO.3M],[RHO.1Y],[RHO.2Y],[RHO.3Y],[RHO.4Y],[RHO.5Y],[RHO.7Y],[RHO.10Y],[RHO.12Y],[RHO.15Y],[RHO.20Y],
[CONVEXITY.3M],[CONVEXITY.1Y],[CONVEXITY.2Y],[CONVEXITY.3Y],[CONVEXITY.4Y],[CONVEXITY.5Y],[CONVEXITY.7Y],[CONVEXITY.10Y],[CONVEXITY.12Y],[CONVEXITY.15Y],[CONVEXITY.20Y])
) AS PIVOT_RESULT order by ticketid asc


-- 8���� --
select * from HanwhaComputations.dbo.Job where valuationDate = '2020-08-31' and statuscode = '1' and ProjectionName  like '%200831%' order by StartAt desc
--and recordsfailed = '0' 

SELECT * FROM (
	SELECT TicketId
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView 
	WHERE TicketId IN ('1963','1964', '1965', '1966', '1967', '1968', '1969')
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN (
[PV],
[DELTA],[GAMMA],
[RHO.3M],[RHO.1Y],[RHO.2Y],[RHO.3Y],[RHO.4Y],[RHO.5Y],[RHO.7Y],[RHO.10Y],[RHO.12Y],[RHO.15Y],[RHO.20Y],
[CONVEXITY.3M],[CONVEXITY.1Y],[CONVEXITY.2Y],[CONVEXITY.3Y],[CONVEXITY.4Y],[CONVEXITY.5Y],[CONVEXITY.7Y],[CONVEXITY.10Y],[CONVEXITY.12Y],[CONVEXITY.15Y],[CONVEXITY.20Y])
) AS PIVOT_RESULT order by ticketid asc


-- 7���� --
select * from HanwhaComputations.dbo.Job where valuationDate = '2020-06-30' and statuscode = '1' and ProjectionName  like '%200630%' order by StartAt desc
--and recordsfailed = '0' 

SELECT * FROM (
	SELECT TicketId
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView 
	WHERE TicketId IN ('853','843', '844', '845', '846', '847', '848')
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN (
[PV],
[DELTA],[GAMMA],
[RHO.3M],[RHO.1Y],[RHO.2Y],[RHO.3Y],[RHO.4Y],[RHO.5Y],[RHO.7Y],[RHO.10Y],[RHO.12Y],[RHO.15Y],[RHO.20Y],
[CONVEXITY.3M],[CONVEXITY.1Y],[CONVEXITY.2Y],[CONVEXITY.3Y],[CONVEXITY.4Y],[CONVEXITY.5Y],[CONVEXITY.7Y],[CONVEXITY.10Y],[CONVEXITY.12Y],[CONVEXITY.15Y],[CONVEXITY.20Y])
) AS PIVOT_RESULT


-- 6���� --
select * from HanwhaComputations.dbo.Job where valuationDate = '2020-06-30' and statuscode = '1' and ProjectionName  like '%200630%' order by StartAt desc
--and recordsfailed = '0' 

SELECT * FROM (
	SELECT TicketId
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView 
	WHERE TicketId IN ('362','363', '364', '371', '372', '373', '374')
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN (
[PV],
[DELTA],[GAMMA],
[RHO.3M],[RHO.1Y],[RHO.2Y],[RHO.3Y],[RHO.4Y],[RHO.5Y],[RHO.7Y],[RHO.10Y],[RHO.12Y],[RHO.15Y],[RHO.20Y],
[CONVEXITY.3M],[CONVEXITY.1Y],[CONVEXITY.2Y],[CONVEXITY.3Y],[CONVEXITY.4Y],[CONVEXITY.5Y],[CONVEXITY.7Y],[CONVEXITY.10Y],[CONVEXITY.12Y],[CONVEXITY.15Y],[CONVEXITY.20Y])
) AS PIVOT_RESULT



-- 5���� --
select * from HanwhaComputations.dbo.Job where valuationDate = '2020-05-29' and statuscode = '1' and ProjectionName  like '%200529%' order by StartAt desc
--and recordsfailed = '0' 

SELECT * FROM (
	SELECT TicketId
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView 
	WHERE TicketId IN ('194','195', '196', '197', '198', '199', '200')
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN (
[PV],
[DELTA],[GAMMA],
[RHO.3M],[RHO.1Y],[RHO.2Y],[RHO.3Y],[RHO.4Y],[RHO.5Y],[RHO.7Y],[RHO.10Y],[RHO.12Y],[RHO.15Y],[RHO.20Y],
[CONVEXITY.3M],[CONVEXITY.1Y],[CONVEXITY.2Y],[CONVEXITY.3Y],[CONVEXITY.4Y],[CONVEXITY.5Y],[CONVEXITY.7Y],[CONVEXITY.10Y],[CONVEXITY.12Y],[CONVEXITY.15Y],[CONVEXITY.20Y])
) AS PIVOT_RESULT


-- 4���� --
select * from Hanwha2Computations.dbo.Job where valuationDate = '2020-04-29'  ProjectionName  like '%200228%'and statuscode = '1' and ProjectionName  like '%200429%' order by StartAt desc
--and recordsfailed = '0' 

SELECT * FROM (
	SELECT TicketId
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView 
	WHERE TicketId IN ('194','195', '196', '197', '198', '199', '200')
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN (
[PV],
[DELTA],[GAMMA],
[RHO.3M],[RHO.1Y],[RHO.2Y],[RHO.3Y],[RHO.4Y],[RHO.5Y],[RHO.7Y],[RHO.10Y],[RHO.12Y],[RHO.15Y],[RHO.20Y],
[CONVEXITY.3M],[CONVEXITY.1Y],[CONVEXITY.2Y],[CONVEXITY.3Y],[CONVEXITY.4Y],[CONVEXITY.5Y],[CONVEXITY.7Y],[CONVEXITY.10Y],[CONVEXITY.12Y],[CONVEXITY.15Y],[CONVEXITY.20Y])
) AS PIVOT_RESULT