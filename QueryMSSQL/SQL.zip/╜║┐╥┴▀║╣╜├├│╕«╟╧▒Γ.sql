 SELECT * FROM SAP_IRS_Swap_Info WHERE settlementDate = dbo.fnNextWorkDay('2021-10-25')

 select * from hanwhainput.dbo.IRSwap

 SELECT * FROM hedgeos.dbo.Swap_Info
 insert into hedgeos.dbo.Swap_Info select * from SAP_IRS_Swap_Info where swapcode in
 (
'211022IRS04Y020150P',
'211022IRS10Y020845R',
'211022IRS15Y020575R',
'211022IRS20Y019725R')

insert into hedgeos.dbo.Swap_Info
select '211022IRS20Y019650R','0','2021-10-25','1','1','1','300000000','6','2','2','1','0.01965','1','6','0','20','2041-10-25','2','1'

insert into hedgeos.dbo.HoldingList select '2021-10-25', '211025IRS20Y019700R', 'Swap', NULL, 'DBCITIBNP', '-1','60000000000.00000000','15'

insert into hedgeos.dbo.HoldingList select '2021-10-25', '211025IRS04Y020325P', 'Swap', NULL, 'DBCITI', '1','60000000000.00000000','15'


insert into HoldingList select '2021-10-22', '211022IRS10Y020845R', 'Swap', NULL, 'KYOBO', '-1','23000000000.00000000','15'

insert into HoldingList select '2021-10-22', '211022IRS10Y020845R', 'Swap', NULL, 'KYOBO', '-1','23000000000.00000000','15'



select * from HoldingList where date ='2021-10-22'
