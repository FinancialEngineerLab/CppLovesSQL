
  select * from HanwhaComputations.dbo.Job
	where valuationdate ='2021-05-04' and statuscode ='1'
		and RecordsFailed ='0'
		and ticketid not in ('955','952','881', '930',
'929',
'928',
'927')-- and jobname not like '%Type5%'
				order by StartAt desc

  select * from HanwhaComputations.dbo.Job
	where valuationdate ='2021-05-03' and statuscode ='1'
		and RecordsFailed ='0'
		and ticketid not in ('955','952','881', '930',
'918',
'917',
'916',
'915') and jobname like '%1y%'-- and jobname not like '%Type5%'
				order by StartAt desc

  select * from HanwhaComputations.dbo.Job
	where valuationdate ='2021-04-30' and statuscode ='1'
		and RecordsFailed ='0' and jobname like '%20y%'
		and ticketid not in ('955','952','881')-- and jobname not like '%Type5%'
				order by StartAt desc

  
  select * from HanwhaComputations.dbo.Job where StatusCode = '1' and RecordsFailed ='0'
				order by StartAt desc
  
  select * from HanwhaComputations.dbo.Job where StatusCode = '1' and RecordsFailed ='0' and jobname like '%SCT%'
				order by StartAt desc
				
select * from hanwhainput.dbo.TB_ST1MV01V_EXPT_BAS_MAIN where HEDG_BLOK_DVSN= '5' and clog_ym = '202105'

SELECT * FROM (
	SELECT
	b.TicketId
	,b.JobName
	,b.JobSetId
	,b.ValuationDate
	,c.IRKD_CODE_DTAL
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView A inner join HanwhaComputations.dbo.job B on a.ticketid = b.TicketId
											inner join hanwhainput.dbo.TB_ST1MV01V_EXPT_BAS_MAIN c on a.RecordId = c.POLY_NO 
	WHERE a.TicketId IN (
'1454',
'1453',
'1452',
'1451',
'1450',
'1449',
'1448',
'1447',
'1446',
'1445',
'1444',
'1443',
'1442',
'1441',
'1440',
'1439',
'1438',
'1437',
'1436',
'1435',
'1434',
'1433',
'1432',
'1431',
'1430',
'1429',
'1428',
'1427',
'1426',
'1425',
'1424',
'1423',
'1422',
'1421',
'1420',
'1419',
'1418',
'1417',
'1416',
'1415',
'1414',
'1413',
'1412',
'1411',
'1410',
'1409'
	)
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
		and c.CLOG_YM = '202105'and c.HEDG_BLOK_DVSN = '5'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN (
[PV],
[DELTA],
[RHO.3M],[RHO.1Y],[RHO.2Y],[RHO.3Y],[RHO.4Y],[RHO.5Y],[RHO.7Y],[RHO.10Y],[RHO.12Y],[RHO.15Y],[RHO.20Y])) AS PIVOT_RESULT order by JobSetId asc





SELECT * FROM (
	SELECT
	b.TicketId
	,b.JobSetId
	,c.IRKD_CODE_DTAL
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView A inner join HanwhaComputations.dbo.job B on a.ticketid = b.TicketId
											inner join hanwhainput.dbo.TB_ST1MV01V_EXPT_BAS_MAIN c on a.RecordId = c.POLY_NO 
	WHERE a.TicketId IN (
'1160',
'1159',
'1158',
'1157',
'1156',
'1155',
'1154',
'1153',
'1152',
'1151',
'1150',
'1149',
'1136',
'1133',
'1129',
'1128',
'1122',
'1066',
'1065',
'1064',
'1063',
'1057'
	)
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
		and c.CLOG_YM = '202105' and c.HEDG_BLOK_DVSN = '5' and c.IRKD_CODE_dtal in ('1795','1836','1871')
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN (
[PV],
[DELTA],
[RHO.3M],[RHO.1Y],[RHO.2Y],[RHO.3Y],[RHO.4Y],[RHO.5Y],[RHO.7Y],[RHO.10Y],[RHO.12Y],[RHO.15Y],[RHO.20Y])) AS PIVOT_RESULT order by JobSetId asc











  

--2�ܰ�
SELECT * FROM ( select
	c.ValuationDate
	,b.HEDG_BLOK_DVSN
	,right(c.JobName,3) as [Shift]
	,REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView A inner join Hanwhainput.dbo.TB_ST1MV01V_EXPT_BAS B on a.recordid = b.poly_no
	inner join HanwhaComputations.dbo.job C on c.TicketId  =a.TicketId
WHERE a.TicketId IN (
'1034',
'1033',
'1032',
'1031')
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
		and clog_ym = '202103'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN (
[PV])
) AS PIVOT_RESULT-- order by ticketid asc





--2�ܰ�
SELECT * FROM ( select
	c.ValuationDate
	,b.HEDG_BLOK_DVSN
	,REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView A inner join Hanwhainput.dbo.TB_ST1MV01V_EXPT_BAS B on a.recordid = b.poly_no
	inner join HanwhaComputations.dbo.job C on c.TicketId  =a.TicketId
WHERE a.TicketId IN (
'1229')
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
		and clog_ym = '202105'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN (
[PV])
) AS PIVOT_RESULT-- order by ticketid asc

