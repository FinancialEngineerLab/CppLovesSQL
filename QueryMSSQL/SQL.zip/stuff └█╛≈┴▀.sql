IF OBJECT_ID('tempdb..#temp') is not null
begin
drop table #temp
end

INSERT INTO hedgeos.dbo.HoldingList
SELECT
                                       	'@Date', '@ProductCode',
                                       	'Swap', NULL,
										
										case 
                                       		when kontrh = '3051471713' then 'CA'
                                       		when kontrh = '4007143724' then 'BNP'
                                       		when kontrh = '6007142596' then 'CITI'
                                       		when kontrh = '7055741277' then 'MS'
                                       		when kontrh = '8058923498' then 'JPM'
                                       		when kontrh = '9007001879' then 'KYOBO'
                                            when kontrh = '1007143401' then 'DB'
                                       		else NULL
                                       	end ,
                                       	case
                                       		when right('@ProductCode', 1) = 'R' then -1
                                       		when right('@ProductCode', 1) = 'P' then 1
                                       		else -1
                                       	end,
                                       	cast(fnotionalp as numeric) * 100,
                                       	'15'
									   into #temp
                                       from hedgeos.dbo.ZFCFM_MCI_OTC001
                                       where '@ProductCode'
                                       		= (RIGHT(xvtrab, 6) + 'IRS' 
                                       		+ REPLICATE('0', 2 - LEN(CAST(FLOOR(DATEDIFF(DD, xlavo, xlabi) / 365.0) AS VARCHAR)))
                                       		+ CAST(FLOOR(DATEDIFF(DD, xlavo, xlabi) / 365.0) AS VARCHAR) 
                                               + 'Y' 
                                       		+ CASE WHEN CAST(pzinssvn AS float) = 0 THEN REPLICATE('0', 6 - LEN(CONVERT(VARCHAR(6), round(CONVERT(FLOAT, pzinssv) * 10000,0))))
                                       		+ CONVERT(VARCHAR(6), round(CONVERT(FLOAT, pzinssv) * 10000,0))
                                       		+ 'P' ELSE REPLICATE('0', 6 - LEN(CONVERT(VARCHAR(6), round(CONVERT(FLOAT, pzinssvn) * 10000,0))))
                                       		+ CONVERT(VARCHAR(6), round(CONVERT(FLOAT, pzinssvn) * 10000,0))
                                               + 'R' END)
											   ) as A 


select distinct
	A.date, A.SwapCode, A.ProductType, A.[NULL], 
	replace(stuff((select ','+ CounterParty from #temp where swapcode = a.SwapCode for xml path('')),1,1,''), ',','') as [CC],
	a.Position,a.Notional, a.UserId
		from 
			(SELECT 
                                       	'@Date' as [Date], '@ProductCode' as [SwapCode],
                                       	'Swap' as [ProductType], NULL as [NULL],
										
										case 
                                       		when kontrh = '3051471713' then 'CA'
                                       		when kontrh = '4007143724' then 'BNP'
                                       		when kontrh = '6007142596' then 'CITI'
                                       		when kontrh = '7055741277' then 'MS'
                                       		when kontrh = '8058923498' then 'JPM'
                                       		when kontrh = '9007001879' then 'KYOBO'
                                            when kontrh = '1007143401' then 'DB'
                                       		else NULL
                                       	end as [CounterParty],
                                       	case
                                       		when right('@ProductCode', 1) = 'R' then -1
                                       		when right('@ProductCode', 1) = 'P' then 1
                                       		else -1
                                       	end as [Position],
                                       	cast(fnotionalp as numeric) * 100 as [Notional],
                                       	'15' as [UserId]
									   
                                       from hedgeos.dbo.ZFCFM_MCI_OTC001
                                       where '@ProductCode'
                                       		= (RIGHT(xvtrab, 6) + 'IRS' 
                                       		+ REPLICATE('0', 2 - LEN(CAST(FLOOR(DATEDIFF(DD, xlavo, xlabi) / 365.0) AS VARCHAR)))
                                       		+ CAST(FLOOR(DATEDIFF(DD, xlavo, xlabi) / 365.0) AS VARCHAR) 
                                               + 'Y' 
                                       		+ CASE WHEN CAST(pzinssvn AS float) = 0 THEN REPLICATE('0', 6 - LEN(CONVERT(VARCHAR(6), round(CONVERT(FLOAT, pzinssv) * 10000,0))))
                                       		+ CONVERT(VARCHAR(6), round(CONVERT(FLOAT, pzinssv) * 10000,0))
                                       		+ 'P' ELSE REPLICATE('0', 6 - LEN(CONVERT(VARCHAR(6), round(CONVERT(FLOAT, pzinssvn) * 10000,0))))
                                       		+ CONVERT(VARCHAR(6), round(CONVERT(FLOAT, pzinssvn) * 10000,0))
                                               + 'R' END)
											   ) as A 
											group by a.date, a.SwapCode, a.CounterParty, A.ProductType, A.[NULL], a.Position,a.Notional, a.UserId