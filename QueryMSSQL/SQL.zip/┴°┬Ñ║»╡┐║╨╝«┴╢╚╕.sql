
select * from Hanwha2Computations.dbo.Job order by StartAt desc, ValuationDate desc

select * from Hanwha2Computations.dbo.Job where jobname like'%base%'and ValuationDate >='2021-10-29'and recordsfailed = '0' and statuscode = '1' order by  ValuationDate asc, startat desc

select * from Hanwha2Computations.dbo.Job where jobname like'%base%'and ValuationDate >='2021-10-29'and recordsfailed = '0' and statuscode = '1' order by  startat desc

select * from Hanwha2Computations.dbo.Job where jobname like'%eq%' and jobname not like '%ir%'and ValuationDate >='2021-10-29' and  recordsfailed = '0' and statuscode = '1' order by ValuationDate asc

select * from Hanwha2Computations.dbo.Job where jobname like'%eqir%' and ValuationDate >='2021-10-29' and  recordsfailed = '0' and statuscode = '1' order by ValuationDate asc

select * from Hanwha2Computations.dbo.Job where jobname like'%bond%'and ValuationDate >='2021-09-30'and valuationdate <='2021-10-22' and  recordsfailed = '0' and statuscode = '1' order by ValuationDate asc

select * from Hanwha2Computations.dbo.Job where jobname like'%fund%'and ValuationDate >='2021-09-30'and valuationdate <='2021-10-22' and  recordsfailed = '0' and statuscode = '1' order by ValuationDate asc

select * from Hanwha2Computations.dbo.Job where jobname like'%mk%'and ValuationDate >='2021-09-30'and valuationdate <='2021-10-22' and  recordsfailed = '0' and statuscode = '1' order by ValuationDate asc

select * from Hanwha2Computations.dbo.Job where jobname like'%alpha%'and ValuationDate >='2021-09-30'and valuationdate <='2021-10-22' and  recordsfailed = '0' and statuscode = '1' order by ValuationDate asc



--base
SELECT * FROM (
	SELECT
	b.ValuationDate
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE/ 100000000 as [VALUE]
	FROM Hanwha2Computations.dbo.MarkView A inner join Hanwha2Computations.dbo.job B on a.ticketid = b.TicketId
	WHERE a.TicketId IN
(
'24144',
'24143',
'24142',
'24141',
'24140',
'24139',
'24234',
'24233',
'24232',
'24231',
'24230',
'24229',
'24228',
'24227',
'24226',
'24225',
'24224',
'24223',
'24222',
'24221',
'24220',
'24219',
'24218',
'24217',
'24216',
'24215',
'24214',
'24213',
'24212',
'24211',
'24210',
'24209',
'24208',
'24207',
'24206',
'24205',
'24204',
'24203',
'24202',
'24201',
'24200',
'24199',
'24198',
'24197',
'24196',
'24195',
'24194',
'24193',
'24192',
'24191',
'24190',
'24189',
'24188',
'24187',
'24186',
'24185',
'24184',
'24183',
'24182',
'24181',
'24180',
'24179',
'24178',
'24177',
'24176',
'24175',
'24174',
'24173',
'24172',
'24171',
'24170',
'24169',
'24168',
'24167',
'24166',
'24165',
'24164',
'24163',
'24162',
'24161',
'24160',
'24159',
'24158',
'24157',
'24156',
'24155',
'24154',
'24153',
'24152',
'24151',
'24150',
'24149',
'24148',
'24147',
'24146',
'24145'
	)
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
		and a.RecordId in (select poly_no from hanwhainput.dbo.Schedule where CLOG_YM ='202109' and entrydate <= b.ValuationDate)
		and b.JobName not like '%IRS%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN ([PV])) AS PIVOT_RESULT order by ValuationDate asc



--eq
SELECT * FROM (
	SELECT
	b.ValuationDate
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE /100000000 as [VALUE]
	FROM Hanwha2Computations.dbo.MarkView A inner join Hanwha2Computations.dbo.job B on a.ticketid = b.TicketId
	WHERE a.TicketId IN
(
'24235',
'24236',
'24237',
'24238',
'24239',
'24240',
'24241',
'24242',
'24243',
'24244',
'24245',
'24246',
'24247',
'24248',
'24249',
'24250',
'24251',
'24252',
'24253',
'24254',
'24255',
'24256',
'24257',
'24258',
'24259',
'24260',
'24261',
'24262',
'24263',
'24264',
'24265',
'24266',
'24267',
'24268',
'24269',
'24270',
'24271',
'24272',
'24273',
'24274',
'24275',
'24276',
'24277',
'24278',
'24279',
'24280',
'24281',
'24282',
'24283',
'24284',
'24285',
'24286',
'24287',
'24288',
'24289',
'24290',
'24291',
'24292',
'24293',
'24294',
'24295',
'24296',
'24297',
'24298',
'24299',
'24300',
'24301',
'24302',
'24303',
'24304',
'24305',
'24306',
'24307',
'24308',
'24309',
'24310',
'24311',
'24312',
'24313',
'24314',
'24315',
'24316',
'24317',
'24318',
'24319',
'24320',
'24321',
'24322',
'24323',
'24324'
	)
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
		and a.RecordId in (select poly_no from hanwhainput.dbo.Schedule where CLOG_YM ='202109' and entrydate <= b.ValuationDate)
		and b.JobName not like '%IRS%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN ([PV])) AS PIVOT_RESULT order by ValuationDate asc




--eq
SELECT * FROM (
	SELECT
	b.ValuationDate
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE /100000000 as [VALUE]
	FROM Hanwha2Computations.dbo.MarkView A inner join Hanwha2Computations.dbo.job B on a.ticketid = b.TicketId
	WHERE a.TicketId IN
(
'24235',
'24236',
'24237',
'24238',
'24239',
'24240',
'24241',
'24242',
'24243',
'24244',
'24245',
'24246',
'24247',
'24248',
'24249',
'24250',
'24251',
'24252',
'24253',
'24254',
'24255',
'24256',
'24257',
'24258',
'24259',
'24260',
'24261',
'24262',
'24263',
'24264',
'24265',
'24266',
'24267',
'24268',
'24269',
'24270',
'24271',
'24272',
'24273',
'24274',
'24275',
'24276',
'24277',
'24278',
'24279',
'24280',
'24281',
'24282',
'24283',
'24284',
'24285',
'24286',
'24287',
'24288',
'24289',
'24290',
'24291',
'24292',
'24293',
'24294',
'24295',
'24296',
'24297',
'24298',
'24299',
'24300',
'24301',
'24302',
'24303',
'24304',
'24305',
'24306',
'24307',
'24308',
'24309',
'24310',
'24311',
'24312',
'24313',
'24314',
'24315',
'24316',
'24317',
'24318',
'24319',
'24320',
'24321',
'24322',
'24323',
'24324'
	)
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
		and a.RecordId in (select poly_no from hanwhainput.dbo.Schedule where CLOG_YM ='202109' and entrydate <= b.ValuationDate)
		and b.JobName not like '%IRS%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN ([PV])) AS PIVOT_RESULT order by ValuationDate asc





select * from Hanwha2Computations.dbo.Job where jobname like'%mk%'and ValuationDate >='2021-08-31'and jobname not like '%IRS%' and recordsfailed = '0' and statuscode = '1' order by ValuationDate desc

select * from Hanwha2Computations.dbo.Job where jobname like '%alpha%' and ValuationDate >='2021-08-31' order by StartAt desc

select * from Hanwha2Computations.dbo.Job where jobname like '%alpha%' and ValuationDate = '2021-09-28' order by StartAt desc


select * from Hanwha2Computations.dbo.Job where jobname like'%mk%'and ValuationDate >='2021-08-31' order by StartAt desc
select * from Hanwha2Computations.dbo.Job where jobname like'%fund%' and ValuationDate >='2021-08-31' and recordsfailed = '0' and statuscode = '1' order by StartAt desc

select * from Hanwha2Computations.dbo.Job where jobname like'%fund%' and ValuationDate ='2021-09-10' and recordsfailed = '0' and statuscode = '1' order by StartAt desc



select * from Hanwha2Computations.dbo.Job where jobname like'%eq%'and ValuationDate >='2021-08-31'and recordsfailed = '0' and statuscode = '1' order by StartAt desc

select * from Hanwha2Computations.dbo.Job where jobname like'%EQ%' and ValuationDate ='2021-09-23' and recordsfailed = '0' and statuscode = '1' order by StartAt desc


select * from Hanwha2Computations.dbo.Job where jobname like'%fund%' and ValuationDate >='2021-08-31' and recordsfailed = '0' and statuscode = '1' order by StartAt desc

select * from Hanwha2Computations.dbo.Job where jobname like'%fund%' and ValuationDate ='2021-09-10' and recordsfailed = '0' and statuscode = '1' order by StartAt desc


select * from Hanwha2Computations.dbo.Job where jobname like'%bond%'and ValuationDate >='2021-08-31'and recordsfailed = '0' and statuscode = '1' order by StartAt desc

