
select r.ticketid,r.jobsetid,r.jobname, s.irkd_code_dtal,r.valuationDate,r.productname, count(*) as numofpolicy,sum(r.value) as value
, r.Scenario ,r.StatusCode, r.RecordsFailed, r.StartAt, r.FinishAt
from (
select d.ticketid as ticketid,d.JobSetId as jobsetid ,d.Jobname as jobname, a.productname, a.value as value
,a.ScenarioDescription as Scenario, d.StatusCode, d.RecordsFailed, d.StartAt, d.FinishAt, d.ValuationDate, a.recordid
from HanwhaComputations.dbo.markview a
inner join HanwhaComputations.dbo.Job d on d.ticketid=a.ticketid 
WHERE
(productname like 'PV_GMDB' or productname like 'PV_GMDB.CONVEXITY%' OR productname like 'PV_GMDB.DELTA.KOSPI' OR productname like 'PV_GMDB.GAMMA%' OR productname like 'PV_GMDB.RHO%'
or productname like 'PV_GMAB' or productname like 'PV_GMAB.CONVEXITY%' OR productname like 'PV_GMAB.DELTA.KOSPI' OR productname like 'PV_GMAB.GAMMA%' OR productname like 'PV_GMAB.RHO%'
or productname like 'PV_GLWB' or productname like 'PV_GLWB.CONVEXITY%' OR productname like 'PV_GLWB.DELTA.KOSPI' OR productname like 'PV_GLWB.GAMMA%' OR productname like 'PV_GLWB.RHO%'
or productname like 'PV_GMWB' or productname like 'PV_GMWB.CONVEXITY%' OR productname like 'PV_GMWB.DELTA.KOSPI' OR productname like 'PV_GMWB.GAMMA%' OR productname like 'PV_GMWB.RHO%' )
and a.TicketId in (
select top 1 ticketid from HanwhaComputations.dbo.Job
WHERE statuscode = '1' and RecordsFailed = '0' and jobsetid ='211008891'
union
select top 1 ticketid from HanwhaComputations.dbo.Job
WHERE statuscode = '1' and RecordsFailed = '0' and jobsetid ='211008892'
union
select top 1 ticketid from HanwhaComputations.dbo.Job
WHERE statuscode = '1'  and RecordsFailed = '0'and jobsetid ='211008893'
union
select top 1 ticketid from HanwhaComputations.dbo.Job
WHERE statuscode = '1'  and RecordsFailed = '0'and jobsetid ='211008894'
union
select top 1 ticketid from HanwhaComputations.dbo.Job
WHERE statuscode = '1'  and RecordsFailed = '0'and jobsetid ='211008895'
union
select top 1 ticketid from HanwhaComputations.dbo.Job
WHERE statuscode = '1'  and RecordsFailed = '0'and jobsetid ='211008896'
union
select top 1 ticketid from HanwhaComputations.dbo.Job
WHERE statuscode = '1'  and RecordsFailed = '0'and jobsetid ='211008897')
) r inner join HanwhaInput.dbo.schedule s on r.recordid = s.POLY_NO
where s.clog_ym = '202108' and entrydate <='2021-10-12'
group by r.ticketid,r.jobsetid,r.jobname,s.irkd_code_dtal, r.productname, r.Scenario, r.StatusCode, r.RecordsFailed, r.StartAt, r.FinishAt, r.ValuationDate
order by r.jobsetid asc, jobname, productname, scenario asc;
