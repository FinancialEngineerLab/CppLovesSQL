	
	
	
	
	
	select * from Hanwha2Computations.dbo.job where jobname like '%IRS%' and ValuationDate >='2021-10-29' and jobsetid like '%99%' 
	and jobname  like '%mk%'
	order by startat desc
	
	
	
	
	
	select * from Hanwha2Computations.dbo.job where jobname like '%IRS%' and ValuationDate >='2021-10-29' and jobsetid like '%02%' 
	and jobname not like '%mk2%'
	order by startat desc
	
	

	
	
	select * from Hanwha2Computations.dbo.job where jobname like '%IRS%' and ValuationDate >='2021-10-29' and jobsetid like '%01%' 
	and jobname  not like '%mk2%'
	order by startat desc
	
	select * from HanwhaComputations.dbo.job where jobname like '%IRS%' and ValuationDate >='2021-10-29' and jobsetid like '%00%' 
	and jobname  not like '%mk2%'
	order by startat desc
	
		
	
	select * from Hanwha2Computations.dbo.job where jobname like '%IRS%' and ValuationDate >='2021-11-30' and jobsetid like '%01%' 
	and jobname  like '%mk%'
	order by startat desc
	
	
	select * from Hanwha2Computations.dbo.job where jobname like '%IRS%' and ValuationDate >='2021-11-30' and jobsetid like '%01%' 
	and jobname  not like '%mk%'
	order by startat desc
	
	select
	b.ValuationDate,
	sum(case when right(d.productcode, 1) = 'R' then value * d.notional / 1000000000.0 * -1.0
		 when right(d.productcode, 1) = 'P' then value * d.notional /		1000000000.0 * 1.0
	end) /10000000.0 as [PV]
	from Hanwha2Computations.dbo.markview A
	inner join hanwhainput.dbo.IRSwap c on  A.RecordId = C.InstrumentId
	inner join Hanwha2Computations.dbo.job B on b.TicketId = a.TicketId
	inner join hedgeos.dbo.HoldingList d on c.SwapCode = d.ProductCode and d.date = b.ValuationDate
	where d.date >='2021-11-30'
	and hedgeos.dbo.fnprevworkday(c.StartDate) <d.Date
	and a.ProductName = 'SWAPPV'
	and a.ticketid in
	( 
'27198',
'27196',
'27194',
'27192',
'27190',
'27188',
'27186',
'27184',
'27182',
'27180',
'27178',
'27176',
'27174',
'27172',
'27170',
'27168',
'27166',
'27164',
'27162',
'27160',
'27158',
'27156',
'27154',
'27152'
	)
	group by b.ValuationDate
	


	
	
	select
	b.ValuationDate,
	sum(case when right(d.productcode, 1) = 'R' then value * d.notional / 1000000000.0 * -1.0
		 when right(d.productcode, 1) = 'P' then value * d.notional /		1000000000.0 * 1.0
	end) /10000000.0 as [PV]
	from HanwhaComputations.dbo.markview A
	inner join hanwhainput.dbo.IRSwap c on  A.RecordId = C.InstrumentId
	inner join HanwhaComputations.dbo.job B on b.TicketId = a.TicketId
	inner join hedgeos.dbo.HoldingList d on c.SwapCode = d.ProductCode and d.date = b.ValuationDate
	where d.date >='2021-11-30'
	and hedgeos.dbo.fnprevworkday(c.StartDate) =d.Date
	and a.ProductName = 'SWAPPV'
	and a.ticketid in
	(
'13626',
'13618',
'13610',
'13592',
'13584',
'13576',
'13568',
'13560',
'13552',
'13544',
'13536',
'13528',
'13520',
'13512',
'13504',
'13496',
'13488',
'13479',
'13471',
'13463',
'13455',
'13447',
'13439',
'13424',
'13416',
'13400',
'13392',
'13384',
'13376',
'13368',
'13360',
'13351',
'13337',
'13329',
'13320',
'13297',
'13289',
'13281',
'13273',
'13265',
'13257',
'13249',
'13218',
'13210',
'13202',
'13180'
	)
	group by b.ValuationDate
	


	
	select
	b.ValuationDate,
	sum(case when right(d.productcode, 1) = 'R' then value * d.notional / 1000000000.0 * -1.0
		 when right(d.productcode, 1) = 'P' then value * d.notional /		1000000000.0 * 1.0
	end) /10000000.0 as [PV]
	from Hanwha2Computations.dbo.markview A
	inner join hanwhainput.dbo.IRSwap c on  A.RecordId = C.InstrumentId
	inner join Hanwha2Computations.dbo.job B on b.TicketId = a.TicketId
	inner join hedgeos.dbo.HoldingList d on c.SwapCode = d.ProductCode and d.date = b.ValuationDate
	where d.date >='2021-10-29'
	and hedgeos.dbo.fnPrevWorkDay(c.StartDate) <= d.Date
	and a.ProductName = 'SWAPPV'
	and a.ticketid in
	(
'25519',
'25517',
'25515',
'25513',
'25511',
'25509',
'25507',
'25505',
'25503',
'25501',
'25499',
'25497',
'25495',
'25493',
'25491',
'25489',
'25487',
'25485',
'25483',
'25481',
'25479',
'25477'
	)
	group by b.ValuationDate


	
	
	select
	b.ValuationDate,
	sum(case when right(d.productcode, 1) = 'R' then value * d.notional / 1000000000.0 * -1.0
		 when right(d.productcode, 1) = 'P' then value * d.notional /		1000000000.0 * 1.0
	end) /10000000.0 as [PV]
	from Hanwha2Computations.dbo.markview A
	inner join hanwhainput.dbo.IRSwap c on  A.RecordId = C.InstrumentId
	inner join Hanwha2Computations.dbo.job B on b.TicketId = a.TicketId
	inner join hedgeos.dbo.HoldingList d on c.SwapCode = d.ProductCode and d.date = b.ValuationDate
	where d.date >='2021-10-29'
	and hedgeos.dbo.fnPrevWorkDay(c.StartDate) < d.Date
	and a.ProductName = 'SWAPPV'
	and a.ticketid in
	(
'25323',
'25325',
'25327',
'25329',
'25331',
'25333',
'25335',
'25337',
'25339',
'25411',
'25341',
'25343',
'25345',
'25347',
'25349',
'25351',
'25353',
'25355',
'25357',
'25359',
'25361',
'25363'
	)
	group by b.ValuationDate


	
	
	select * from HanwhaComputations.dbo.job where jobname like '%IRS%' and ValuationDate >='2021-09-30' and jobsetid like '%000%' order by ValuationDate asc
	

select * from Hanwha2Computations.dbo.Job where jobname like'%IRS%' and jobname like '%mk2%' and ValuationDate >='2021-09-30' and RecordsFailed ='0' and statuscode ='1' order by StartAt desc

select * from Hanwha2Computations.dbo.Job where jobname like'%IRS%'and jobname like '%base%'  and ValuationDate >='2021-09-30' and RecordsFailed ='0' and statuscode ='1' order by StartAt desc


	
	select
	b.ValuationDate,
	sum(case when right(d.productcode, 1) = 'R' then value * d.notional / 1000000000.0 * -1.0
		 when right(d.productcode, 1) = 'P' then value * d.notional /		1000000000.0 * 1.0
	end) /10000000.0 as [PV]
	from Hanwha2Computations.dbo.markview A
	inner join hanwha2input.dbo.IRSwap c on  A.RecordId = C.InstrumentId
	inner join Hanwha2Computations.dbo.job B on b.TicketId = a.TicketId
	inner join hedgeos.dbo.HoldingList d on c.SwapCode = d.ProductCode and d.date = b.ValuationDate
	where d.date >='2021-09-30'
	and hedgeos.dbo.fnPrevWorkDay(c.StartDate) <= d.Date
	and a.ProductName = 'SWAPPV'
	and a.ticketid in
	(
'23187',
'23185',
'23183',
'23181',
'23179',
'23177',
'23175',
'23173',
'23171',
'23169',
'23167',
'23165',
'23163',
'23161',
'23159',
'23157',
'23155',
'23153',
'23151'
	)
	group by b.ValuationDate



select
	a.date,
	sum(case when right(a.productcode, 1) = 'R' then value * b.notional / 1000000000 * -1.0
		 when right(a.productcode, 1) = 'P' then value * b.notional /		1000000000 * 1.0
	end) /10000000 as [PV]
	from hedgeos.dbo.PV_LH A inner join hedgeos.dbo.holdinglist b on a.date = b.date and a.userid = b.userid and a.ProductCode = b.ProductCode
	inner join hanwhainput.dbo.IRSwap c on a.ProductCode = c.SwapCode and b.ProductCode = c.SwapCode
		where a.Type = 'asset' and a.ProductType <> 'EQ' and a.date >='2021-09-30' 
		and hedgeos.dbo.fnPrevWorkDay(c.startDate) <= b.Date
	group by a.date
	order by a.date asc

	select
	a.date,
	sum(case when right(a.productcode, 1) = 'R' then value * b.notional / 1000000000 * -1.0
		 when right(a.productcode, 1) = 'P' then value * b.notional /		1000000000 * 1.0
	end) /10000000 as [PV]
	from hedgeos.dbo.PV_LH A inner join hedgeos.dbo.holdinglist b on a.date = b.date and a.userid = b.userid and a.ProductCode = b.ProductCode
	inner join hanwhainput.dbo.IRSwap c on a.ProductCode = c.SwapCode and b.ProductCode = c.SwapCode
		where a.Type = 'asset' and a.ProductType <> 'EQ' and a.date >='2021-09-29' 
		and hedgeos.dbo.fnPrevWorkDay(c.startDate) < b.Date
		and hedgeos.dbo.fnPrevWorkDay(c.startDate) < a.date
	group by a.date
	order by a.date asc


	select
	b.ValuationDate,
	sum(case when right(d.productcode, 1) = 'R' then value * d.notional / 1000000000.0 * -1.0
		 when right(d.productcode, 1) = 'P' then value * d.notional /		1000000000.0 * 1.0
	end) /10000000.0 as [PV]
	from Hanwha2Computations.dbo.markview A
	inner join hanwha2input.dbo.IRSwap c on  A.RecordId = C.InstrumentId
	inner join Hanwha2Computations.dbo.job B on b.TicketId = a.TicketId
	inner join hedgeos.dbo.HoldingList d on c.SwapCode = d.ProductCode and d.date = b.ValuationDate
	where d.date >='2021-09-30'
	and hedgeos.dbo.fnPrevWorkDay(c.StartDate) < b.ValuationDate
	and a.ProductName = 'SWAPPV'
	and a.ticketid in
	(
'23055',
'23053',
'23052',
'23051',
'23049',
'23048',
'23047',
'23045',
'23044',
'23043',
'23042',
'23041',
'23040',
'23039',
'23038',
'23037',
'23036',
'23035',
'23034'
	)
	group by b.ValuationDate



	select
	b.ValuationDate,
	sum(case when right(d.productcode, 1) = 'R' then value * d.notional / 1000000000.0 * -1.0
		 when right(d.productcode, 1) = 'P' then value * d.notional /		1000000000.0 * 1.0
	end) /10000000.0 as [PV]
	from HanwhaComputations.dbo.markview A
	inner join hanwhainput.dbo.IRSwap c on  A.RecordId = C.InstrumentId
	inner join HanwhaComputations.dbo.job B on b.TicketId = a.TicketId
	inner join hedgeos.dbo.HoldingList d on c.SwapCode = d.ProductCode and d.date = b.ValuationDate
	where d.date >='2021-09-30'
	and hedgeos.dbo.fnPrevWorkDay(c.StartDate) < d.Date
	and a.ProductName = 'SWAPPV'
	and a.ticketid in
	(
'23184',
'23182',
'23180',
'23178',
'23176',
'23174',
'23172',
'23170',
'23168',
'23166',
'23164',
'23162',
'23160',
'23158',
'23156',
'23154',
'23152',
'23150'
	)
	group by b.ValuationDate





	select
	b.ValuationDate,
	sum(case when right(d.productcode, 1) = 'R' then value * d.notional / 1000000000.0 * -1.0
		 when right(d.productcode, 1) = 'P' then value * d.notional /		1000000000.0 * 1.0
	end) /10000000.0 as [PV]
	from Hanwha2Computations.dbo.markview A
	inner join hanwhainput.dbo.IRSwap c on  A.RecordId = C.InstrumentId
	inner join Hanwha2Computations.dbo.job B on b.TicketId = a.TicketId
	inner join hedgeos.dbo.HoldingList d on c.SwapCode = d.ProductCode and d.date = b.ValuationDate
	where d.date >='2021-09-30'
	and c.StartDate < d.Date
	and c.EndDate >= d.Date
	and a.ProductName = 'SWAPPV'
	and d.userid = '15'
	and a.ticketid in
	(

'23149',
'23148',
'23147',
'23146',
'23145',
'23144',
'23143',
'23142',
'23141',
'23140',
'23139',
'23138',
'23137',
'23136',
'23135',
'23134',
'23133',
'23132',
'23131'
	)
	group by b.ValuationDate




	
select * from HanwhaComputations.dbo.Job where jobname like'%IRS%'and ValuationDate >='2021-09-30' and jobsetid like '%000%' and RecordsFailed ='0' and statuscode ='1' order by StartAt desc


select * from hedgeos.dbo.HoldingList where date = '2021-09-30'


	select
	b.ValuationDate,
	sum(case when right(d.productcode, 1) = 'R' then value * d.notional / 1000000000.0 * -1.0
		 when right(d.productcode, 1) = 'P' then value * d.notional /		1000000000.0 * 1.0
	end) /10000000.0 as [PV]
	from HanwhaComputations.dbo.markview A
	inner join hanwhainput.dbo.IRSwap c on  A.RecordId = C.InstrumentId
	inner join HanwhaComputations.dbo.job B on b.TicketId = a.TicketId
	inner join hedgeos.dbo.HoldingList d on c.SwapCode = d.ProductCode and d.date = b.ValuationDate
	where d.date >='2021-09-30'
	and c.StartDate <= d.Date
	and c.EndDate >= d.Date
	and a.ProductName = 'SWAPPV'
	and d.userid = '15'
	and a.ticketid in
	(
'13180',
'13166',
'13149',
'13141',
'13133',
'13107',
'13099',
'13091',
'13078',
'13066',
'13051',
'13043',
'13035',
'13021',
'12985',
'12977',
'12955',
'12940',
'12913',
'12898'
	)
	group by b.ValuationDate