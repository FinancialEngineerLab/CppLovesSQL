


select * from hanwhainput.dbo.TB_ST1MV01V_EXPT_BAS --29545
where clog_ym = '202106'
and poly_no in (select poly_no from hanwhainput.dbo.Schedule where entrydate >= '2021-07-01' and entrydate <='2021-07-31' and CLOG_YM = '202105') --29788
union
select * from hanwhainput.dbo.TB_ST1MV01V_EXPT_BAS --103483
where clog_ym = '202106'
and poly_no in (select poly_no from hanwhainput.dbo.Schedule where entrydate >= '2021-09-01' and entrydate <='2021-09-30' and CLOG_YM = '202107')--103496
union
select * from hanwhainput.dbo.TB_ST1MV01V_EXPT_BAS -- 76130
where clog_ym = '202106'
and poly_no in (select poly_no from hanwhainput.dbo.Schedule where entrydate >= '2021-10-01' and entrydate <='2021-10-30' and CLOG_YM = '202108')--76144











select a.CLOG_YM,b.POLY_NO, b.IRKD_CODE_DTAL, b.HEDG_BLOK_DVSN, b.CLOG_YM
from hanwhainput.dbo.Schedule A inner join hanwhainput.dbo.TB_ST1MV01V_EXPT_BAS B on a.POLY_NO = b.POLY_NO
where B.CLOG_YM ='202106'  and A.EntryDate <='2021-09-30' and a.EntryDate >='2021-07-01' 
and a.CLOG_YM >='202106'
order by HEDG_BLOK_DVSN asc