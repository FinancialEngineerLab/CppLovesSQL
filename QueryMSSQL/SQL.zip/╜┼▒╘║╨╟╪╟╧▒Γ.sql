

-- Appendix
select * from HanwhaComputations.dbo.Job where ValuationDate ='2021-09-14' order by StartAt desc


SELECT * FROM (
	SELECT
	b.TicketId
	,b.JobName
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView A inner join HanwhaComputations.dbo.job B on a.ticketid = b.TicketId inner join HanwhaInput.dbo.Schedule C on a.RecordId = c.POLY_NO
	WHERE a.TicketId IN (
'12688',
'12687',
'12686',
'12685',
'12684',
'12683',
'12682'
	)
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
		and c.EntryDate <'2021-09-14'
		and c.CLOG_YM ='202107'
		and b.JobName not like '%IRS%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN ([PV],[RHO.1Y],[RHO.2Y],[RHO.3Y],[RHO.4Y],[RHO.5Y],[RHO.7Y],[RHO.10Y],[RHO.12Y],[RHO.15Y],[RHO.20Y])) AS PIVOT_RESULT order by JobName asc


SELECT * FROM (
	SELECT
	b.TicketId
	,b.JobName
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView A inner join HanwhaComputations.dbo.job B on a.ticketid = b.TicketId inner join HanwhaInput.dbo.Schedule C on a.RecordId = c.POLY_NO
	WHERE a.TicketId IN (
'12688',
'12687',
'12686',
'12685',
'12684',
'12683',
'12682'
	)
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
		and c.EntryDate <= '2021-09-14'
		and c.CLOG_YM ='202107'
		and b.JobName not like '%IRS%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN ([PV],[RHO.1Y],[RHO.2Y],[RHO.3Y],[RHO.4Y],[RHO.5Y],[RHO.7Y],[RHO.10Y],[RHO.12Y],[RHO.15Y],[RHO.20Y])) AS PIVOT_RESULT order by JobName asc

