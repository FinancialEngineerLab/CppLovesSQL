

update Hanwha2Internal.dbo.script_Scriptlet set scripttext = replace(scripttext,'R_EQ = KOSPI / SPOT - 1','R_EQ = KOSPI / SPOT - 1 -0.013760186854197800') where EntityId in ('162') and Name in ('Type1Payoff','Type2Payoff','Type3Payoff','Type4Payoff','Type5Payoff','Type6Payoff')
update Hanwha2Internal.dbo.script_Scriptlet set scripttext = replace(scripttext,'R_IR = ZCB_PRICE / ZCB_PRICE_FIRST - 1','R_IR = ZCB_PRICE / ZCB_PRICE_FIRST - 1 -0.003071842100308090') where EntityId in ('162') and Name in ('Type1Payoff','Type2Payoff','Type3Payoff','Type4Payoff','Type5Payoff','Type6Payoff')
update Hanwha2Internal.dbo.script_Scriptlet set scripttext = replace(scripttext,'R_IR2 = ZCBMMF_PRICE / ZCBMMF_PRICE_FIRST - 1','R_IR2 = ZCBMMF_PRICE / ZCBMMF_PRICE_FIRST - 1 -0.000040692604566628') where EntityId in ('162') and Name in ('Type1Payoff','Type2Payoff','Type3Payoff','Type4Payoff','Type5Payoff','Type6Payoff')


update Hanwha2Internal.dbo.script_Scriptlet set scripttext = replace(scripttext,'R_EQ = KOSPI / SPOT - 1','R_EQ = KOSPI / SPOT - 1 -0.013760186854197800') where EntityId in ('162') and Name in ('Type1Payoff','Type2Payoff','Type3Payoff','Type4Payoff','Type5Payoff','Type6Payoff')
update Hanwha2Internal.dbo.script_Scriptlet set scripttext = replace(scripttext,'R_IR = ZCB_PRICE / ZCB_PRICE_FIRST - 1','R_IR = ZCB_PRICE / ZCB_PRICE_FIRST - 1 -0.003071842100308090') where EntityId in ('162') and Name in ('Type1Payoff','Type2Payoff','Type3Payoff','Type4Payoff','Type5Payoff','Type6Payoff')
update Hanwha2Internal.dbo.script_Scriptlet set scripttext = replace(scripttext,'R_IR2 = ZCBMMF_PRICE / ZCBMMF_PRICE_FIRST - 1','R_IR2 = ZCBMMF_PRICE / ZCBMMF_PRICE_FIRST - 1 -0.000040692604566628') where EntityId in ('162') and Name in ('Type1Payoff','Type2Payoff','Type3Payoff','Type4Payoff','Type5Payoff','Type6Payoff')


update Hanwha2Internal.dbo.script_Scriptlet set scripttext = replace(scripttext,'R_EQ = KOSPI / SPOT - 1 -0.013760186854197800','R_EQ = KOSPI / SPOT - 1') where EntityId in ('162') and Name in ('Type1Payoff','Type2Payoff','Type3Payoff','Type4Payoff','Type5Payoff','Type6Payoff')
update Hanwha2Internal.dbo.script_Scriptlet set scripttext = replace(scripttext,'R_IR = ZCB_PRICE / ZCB_PRICE_FIRST - 1 -0.003071842100308090','R_IR = ZCB_PRICE / ZCB_PRICE_FIRST - 1') where EntityId in ('162') and Name in ('Type1Payoff','Type2Payoff','Type3Payoff','Type4Payoff','Type5Payoff','Type6Payoff')
update Hanwha2Internal.dbo.script_Scriptlet set scripttext = replace(scripttext,'R_IR2 = ZCBMMF_PRICE / ZCBMMF_PRICE_FIRST - 1 -0.000040692604566628','R_IR2 = ZCBMMF_PRICE / ZCBMMF_PRICE_FIRST - 1') where EntityId in ('162') and Name in ('Type1Payoff','Type2Payoff','Type3Payoff','Type4Payoff','Type5Payoff','Type6Payoff')


update Hanwha2Internal.dbo.script_Scriptlet set scripttext = replace(scripttext,'R_EQ = KOSPI / SPOT - 1','R_EQ = KOSPI / SPOT - 1 -0.013760186854197800') where EntityId in ('162') and Name in ('Type1Payoff','Type2Payoff','Type3Payoff','Type4Payoff','Type5Payoff','Type6Payoff')
update Hanwha2Internal.dbo.script_Scriptlet set scripttext = replace(scripttext,'R_IR = ZCB_PRICE / ZCB_PRICE_FIRST - 1','R_IR = ZCB_PRICE / ZCB_PRICE_FIRST - 1 -0.003071842100308090') where EntityId in ('162') and Name in ('Type1Payoff','Type2Payoff','Type3Payoff','Type4Payoff','Type5Payoff','Type6Payoff')
update Hanwha2Internal.dbo.script_Scriptlet set scripttext = replace(scripttext,'R_IR2 = ZCBMMF_PRICE / ZCBMMF_PRICE_FIRST - 1','R_IR2 = ZCBMMF_PRICE / ZCBMMF_PRICE_FIRST - 1 -0.000040692604566628') where EntityId in ('162') and Name in ('Type1Payoff','Type2Payoff','Type3Payoff','Type4Payoff','Type5Payoff','Type6Payoff')


EXEC Hanwha2Input.dbo.InputMasterUpdate '202110 ���η�'
select * from Hanwha2Computations.dbo.MarkView where RecordId ='103453221' and ticketid = '23219'

    <Double>2557.6175955660883</Double>
    <String>PV_GMAB</String>
    <Double>1375638.7957370956</Double>
    <String>PV_GMDB</String>
    <Double>137563.87957370942</Double>

    <String>PV_GMAB</String>
    <Double>2162781.0748893125</Double>
    <String>PV_GMDB</String>
    <Double>268601.17895014811</Double>



select * from hanwha2input.dbo.