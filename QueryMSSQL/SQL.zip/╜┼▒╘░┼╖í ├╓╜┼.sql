

-- Schedule --

update hanwhainput.dbo.Schedule set EntryDate = '2021-10-15' where CLOG_YM = '202108' and POLY_NO%12=2 and irkd_code_dtal = '1609'  --11062
update hanwhainput.dbo.Schedule set EntryDate = '2021-10-18' where CLOG_YM = '202108' and POLY_NO%12=3 and irkd_code_dtal = '1609'  --10989
update hanwhainput.dbo.Schedule set EntryDate = '2021-10-19' where CLOG_YM = '202108' and POLY_NO%12=4 and irkd_code_dtal = '1609'  --11072
update hanwhainput.dbo.Schedule set EntryDate = '2021-10-20' where CLOG_YM = '202108' and POLY_NO%12=5 and irkd_code_dtal = '1609'  --10952
update hanwhainput.dbo.Schedule set EntryDate = '2021-10-21' where CLOG_YM = '202108' and POLY_NO%12=6 and irkd_code_dtal = '1609'  --11046
update hanwhainput.dbo.Schedule set EntryDate = '2021-10-22' where CLOG_YM = '202108' and POLY_NO%12=7 and irkd_code_dtal = '1609'  --11105
update hanwhainput.dbo.Schedule set EntryDate = '2021-10-25' where CLOG_YM = '202108' and POLY_NO%12=8 and irkd_code_dtal = '1609'  --11147
update hanwhainput.dbo.Schedule set EntryDate = '2021-10-26' where CLOG_YM = '202108' and POLY_NO%12=9 and irkd_code_dtal = '1609'  --10972
update hanwhainput.dbo.Schedule set EntryDate = '2021-10-27' where CLOG_YM = '202108' and POLY_NO%12=10 and irkd_code_dtal = '1609'  --10993
update hanwhainput.dbo.Schedule set EntryDate = '2021-10-28' where CLOG_YM = '202108' and POLY_NO%12=11 and irkd_code_dtal = '1609'  --11140



select * from hanwhainput.dbo.Schedule  where CLOG_YM = '202108' and POLY_NO%12=4 and irkd_code_dtal = '1609'  --10989

--ROLLBACK
--update hanwhainput.dbo.Schedule set EntryDate = NULL where CLOG_YM = '202107' and POLY_NO%2=0 and irkd_code_dtal = '1610'


select * from hanwhainput.dbo.schedule where CLOG_YM = '202108' and irkd_code_dtal = '1710'

select * from hanwhainput.dbo.TB_ST1MV01V_EXPT_BAS where CLOG_YM = '202108' and irkd_code_dtal = '1613'

select * from hanwha3input.dbo.TB_ST1MV01V_2108_EXPT_BAS_MAIN2 where CLOG_YM = '202108' and irkd_code_dtal = '1609'


--** �� ���������Ͼ�����Ʈ **--


-- HURDLE --


select * from hedgeos.dbo.Hurdle_View order by date desc

select * from hedgeos.dbo.Hurdle where userid = '15' order by date desc



DECLARE @DATE AS DATE
SET @DATE = '2021-10-08'
DELETE FROM HedgeOS.dbo.Hurdle WHERE Date=@DATE AND UserId='15'
INSERT INTO HedgeOS.dbo.Hurdle
SELECT * FROM (
SELECT @DATE AS 'DATE','DELTA'  AS 'AMOUNT',SUM(VALUE)  AS 'VALUE','0.05'  AS 'RATE', '15' AS 'USERID' FROM HedgeOS.dbo.Greeks_EQ WHERE Date=hedgeos.dbo.fnPrevWorkDay(@Date) AND Greeks='DELTA' AND Type<>'ASSET' AND UserId='15' UNION
SELECT @DATE AS 'DATE','RHO01Y' AS 'AMOUNT', [01Y]      AS 'VALUE', '0.2'  AS 'RATE', '15' AS 'USERID' FROM HedgeOS.dbo.Greeks_IR_prev_Liability_View WHERE Date=hedgeos.dbo.fnPrevWorkDay(@Date) AND Greeks='RHO'  AND UserId='15' UNION
SELECT @DATE AS 'DATE','RHO02Y' AS 'AMOUNT', [02Y]      AS 'VALUE', '0.2'  AS 'RATE', '15' AS 'USERID' FROM HedgeOS.dbo.Greeks_IR_prev_Liability_View WHERE Date=hedgeos.dbo.fnPrevWorkDay(@Date) AND Greeks='RHO'  AND UserId='15' UNION
SELECT @DATE AS 'DATE','RHO03Y' AS 'AMOUNT', [03Y]      AS 'VALUE', '0.2'  AS 'RATE', '15' AS 'USERID' FROM HedgeOS.dbo.Greeks_IR_prev_Liability_View WHERE Date=hedgeos.dbo.fnPrevWorkDay(@Date) AND Greeks='RHO'  AND UserId='15' UNION
SELECT @DATE AS 'DATE','RHO04Y' AS 'AMOUNT', [04Y]      AS 'VALUE', '0.2'  AS 'RATE', '15' AS 'USERID' FROM HedgeOS.dbo.Greeks_IR_prev_Liability_View WHERE Date=hedgeos.dbo.fnPrevWorkDay(@Date) AND Greeks='RHO'  AND UserId='15' UNION
SELECT @DATE AS 'DATE','RHO05Y' AS 'AMOUNT', [05Y]      AS 'VALUE', '0.1'  AS 'RATE', '15' AS 'USERID' FROM HedgeOS.dbo.Greeks_IR_prev_Liability_View WHERE Date=hedgeos.dbo.fnPrevWorkDay(@Date) AND Greeks='RHO'  AND UserId='15' UNION
SELECT @DATE AS 'DATE','RHO07Y' AS 'AMOUNT', [07Y]      AS 'VALUE', '0.1'  AS 'RATE', '15' AS 'USERID' FROM HedgeOS.dbo.Greeks_IR_prev_Liability_View WHERE Date=hedgeos.dbo.fnPrevWorkDay(@Date) AND Greeks='RHO'  AND UserId='15' UNION
SELECT @DATE AS 'DATE','RHO10Y' AS 'AMOUNT', [10Y]      AS 'VALUE', '0.1'  AS 'RATE', '15' AS 'USERID' FROM HedgeOS.dbo.Greeks_IR_prev_Liability_View WHERE Date=hedgeos.dbo.fnPrevWorkDay(@Date) AND Greeks='RHO'  AND UserId='15' UNION
SELECT @DATE AS 'DATE','RHO12Y' AS 'AMOUNT', [12Y]      AS 'VALUE', '0.1'  AS 'RATE', '15' AS 'USERID' FROM HedgeOS.dbo.Greeks_IR_prev_Liability_View WHERE Date=hedgeos.dbo.fnPrevWorkDay(@Date) AND Greeks='RHO'  AND UserId='15' UNION
SELECT @DATE AS 'DATE','RHO15Y' AS 'AMOUNT', SUM(VALUE) AS 'VALUE', '0.05' AS 'RATE', '15' AS 'USERID' FROM HedgeOS.dbo.Greeks_IR WHERE Date=hedgeos.dbo.fnPrevWorkDay(@Date) AND Greeks='RHO' AND Tenor='ETC'  AND UserId='15' UNION
SELECT @DATE AS 'DATE','RHO20Y' AS 'AMOUNT', [20Y]      AS 'VALUE', '0.05' AS 'RATE', '15' AS 'USERID' FROM HedgeOS.dbo.Greeks_IR_prev_Liability_View WHERE Date=hedgeos.dbo.fnPrevWorkDay(@Date) AND Greeks='RHO' AND UserId='15' ) B


-- PV ��ȸ --

select * from HanwhaComputations.dbo.Job where ValuationDate ='2021-09-17' order by StartAt desc



select * from HanwhaComputations.dbo.Job order by StartAt desc

update HanwhaComputations.dbo.job set jobsetid = '0' where ticketid in

(
'13159',
'13157',
'13156',
'13155',
'13154',
'13153',
'13152',
'13151',
'13150')

select top 100 * from HanwhaComputations.dbo.PricingFailureView order by TimeStamp desc


select b.ProductName, sum(b.Value) / 100000000 from HanwhaComputations.dbo.job A inner join HanwhaComputations.dbo.MarkView b on a.TicketId = b.TicketId
where a.ticketid = '13162'and b.RecordId in (select poly_no from hanwhainput.dbo.Schedule where entrydate = '2021-10-28' and CLOG_YM ='202108') 
and b.productname in ('PV_GMDB', 'PV_GMAB') group by b.ProductName


select b.ProductName, sum(b.Value)  / 100000000 from HanwhaComputations.dbo.job A inner join HanwhaComputations.dbo.MarkView b on a.TicketId = b.TicketId
where a.ticketid = '13162'and b.RecordId in (select poly_no from hanwhainput.dbo.Schedule where entrydate = '2021-10-28' and CLOG_YM ='202108') 
and b.productname in ('PV_GMDB', 'PV_GMAB') group by b.ProductName



/****** ������� ******/

SELECT A.CLOG_YM 
     , A.HEDG_BLOK_DVSN
	 , COUNT(A.POLY_NO) as COUNT
	 --, SUM(A.SAV) AS SAV
	 , SUM(A.SAV_ORIGN) / 100000000 AS SAV_ORIGN
FROM
    (SELECT B.CLOG_YM 
         , B.HEDG_BLOK_DVSN
		 --, 'HEDGE_TYPE' = CASE WHEN FUND_CODE_01 = 'V9101' THEN '1_Vfund' ELSE HEDG_BLOK_DVSN END
	     , C.POLY_NO
	     , (BAS_VRF - BASC_LOAN) + (ADD_VRF - ADDC_LOAN) AS SAV
		 , (BAS_VRF + ADD_VRF) AS SAV_ORIGN
    FROM [HanwhaInput].[dbo].[TB_ST1MV01V_EXPT_BAS] B inner join hanwhainput.dbo.Schedule C on B.POLY_NO = C.POLY_NO
	WHERE C.EntryDate = '2021-10-28' and C.CLOG_YM = '202108'						
) A where a.CLOG_YM ='202108'
GROUP BY A.CLOG_YM, A.HEDG_BLOK_DVSN


/****** ������� ******/

SELECT A.CLOG_YM 
     , A.HEDG_BLOK_DVSN
	 , COUNT(A.POLY_NO) as COUNT
	 --, SUM(A.SAV) AS SAV
	 , SUM(A.SAV_ORIGN) AS SAV_ORIGN
FROM
    (SELECT B.CLOG_YM 
         , B.HEDG_BLOK_DVSN
		 --, 'HEDGE_TYPE' = CASE WHEN FUND_CODE_01 = 'V9101' THEN '1_Vfund' ELSE HEDG_BLOK_DVSN END
	     , C.POLY_NO
	     , (BAS_VRF - BASC_LOAN) + (ADD_VRF - ADDC_LOAN) AS SAV
		 , (BAS_VRF + ADD_VRF) AS SAV_ORIGN
    FROM [HanwhaInput].[dbo].[TB_ST1MV01V_EXPT_BAS] B inner join hanwhainput.dbo.Schedule C on B.POLY_NO = C.POLY_NO
	WHERE C.EntryDate <= '2021-10-28' and C.CLOG_YM = '202108'						
) A where a.CLOG_YM ='202108'
GROUP BY A.CLOG_YM, A.HEDG_BLOK_DVSN






-- Appendix
select * from HanwhaComputations.dbo.Job where ValuationDate ='2021-10-22' order by StartAt desc


SELECT * FROM (
	SELECT
	b.TicketId
	,b.JobName
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView A inner join HanwhaComputations.dbo.job B on a.ticketid = b.TicketId inner join HanwhaInput.dbo.Schedule C on a.RecordId = c.POLY_NO
	WHERE a.TicketId IN (
'13129',
'13103'
	)
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
		and c.EntryDate <='2021-10-24'
		and c.CLOG_YM ='202108'
		and c.IRKD_CODE_DTAL = '1609'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN ([PV])) AS PIVOT_RESULT order by JobName asc



-- Convexity --
select * from HanwhaComputations.dbo.Job where ValuationDate ='2021-10-22' order by StartAt desc


SELECT * FROM (
	SELECT
	b.TicketId
	,b.JobName
	, case when len(b.jobname) > 7 then right(b.jobname, 9) else 'Base' end as [Shock]
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM HanwhaComputations.dbo.MarkView A inner join HanwhaComputations.dbo.job B on a.ticketid = b.TicketId inner join HanwhaInput.dbo.Schedule C on a.RecordId = c.POLY_NO
	WHERE a.TicketId IN (
'12841',
'12840',
'12839',
'12838',
'12837',
'12836',
'12835',
'12834',
'12833',
'12832',
'12831',
'12830',
'12829',
'12828',
'12827',
'12826',
'12825',
'12824',
'12823',
'12822',
'12820',
'12819',
'12818',
'12817',
'12816',
'12815',
'12814'
	)
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
		and c.EntryDate <='2021-09-29'
		and c.CLOG_YM ='202107'
		and b.JobName not like '%IRS%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN ([PV],[RHO.12Y],[RHO.15Y],[RHO.20Y])) AS PIVOT_RESULT order by JobName asc

