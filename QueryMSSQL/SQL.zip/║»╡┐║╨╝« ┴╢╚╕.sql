

update Hanwha2Internal.dbo.script_Scriptlet set scripttext = replace(scripttext,'R_EQ = KOSPI / SPOT - 1 -0.013760186854197800 -0.013760186854197800 ','R_EQ = KOSPI / SPOT - 1') where EntityId in ('162') and Name in ('Type1Payoff','Type2Payoff','Type3Payoff','Type4Payoff','Type5Payoff','Type6Payoff')
update Hanwha2Internal.dbo.script_Scriptlet set scripttext = replace(scripttext,'R_IR = ZCB_PRICE / ZCB_PRICE_FIRST - 1 %addvalue2%','R_IR = ZCB_PRICE / ZCB_PRICE_FIRST - 1') where EntityId in ('162') and Name in ('Type1Payoff','Type2Payoff','Type3Payoff','Type4Payoff','Type5Payoff','Type6Payoff')"
update Hanwha2Internal.dbo.script_Scriptlet set scripttext = replace(scripttext,'R_IR2 = ZCBMMF_PRICE / ZCBMMF_PRICE_FIRST - 1 %addvalue3%','R_IR2 = ZCBMMF_PRICE / ZCBMMF_PRICE_FIRST - 1') where EntityId in ('162') and Name in ('Type1Payoff','Type2Payoff','Type3Payoff','Type4Payoff','Type5Payoff','Type6Payoff')"


select * from Hanwha2Computations.dbo.Job where jobname like'%IRS%'and ValuationDate >='2021-09-30' and RecordsFailed ='0' and statuscode ='1' order by StartAt desc

select * from Hanwha2Computations.dbo.Job  order by StartAt desc

select * from Hanwha2Internal.dbo.script_Scriptlet order by EntityId desc

select * from Hanwha2Computations.dbo.Job where jobname like '%base%' and ValuationDate >='2021-09-30' and RecordsFailed ='0' and statuscode ='1' order by StartAt desc

select * from HanwhaComputations.dbo.Job where  ValuationDate >='2021-10-28' and RecordsFailed ='0' and statuscode ='1' order by StartAt desc

select * from Hanwha2Computations.dbo.Job where jobname like '%alpha%' and ValuationDate >='2021-09-30' order by StartAt desc
select * from Hanwha2Computations.dbo.Job where jobname like'%mk%'and ValuationDate >='2021-09-30' order by StartAt desc
select * from Hanwha2Computations.dbo.Job where jobname like'%fund%' and ValuationDate >='2021-09-30'order by StartAt desc

select * from Hanwha2Computations.dbo.Job where jobname like'%eq%'and ValuationDate >='2021-09-30'and RecordsFailed ='0' and statuscode ='1' and ProjectionName like '%VA%' order by StartAt desc
select * from Hanwha2Computations.dbo.Job where jobname like'%bond%'and ValuationDate >='2021-09-30' and RecordsFailed ='0' and statuscode ='1' and ProjectionName like '%VA%' order by StartAt desc
-- 10/1 eq type 1,2

select * from Hanwha2Computations.dbo.Job where jobname like'%fund%' and ValuationDate >='2021-09-30' and RecordsFailed ='0' and statuscode ='1' order by StartAt desc


-2539.16781002585


SELECT * FROM (
	SELECT
	'=' as [Valuedate]
	,b.ValuationDate
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE /100000000 as [VALUE]
	FROM Hanwha2Computations.dbo.MarkView A inner join Hanwha2Computations.dbo.job B on a.ticketid = b.TicketId inner join HanwhaInput.dbo.Schedule C on a.RecordId = c.POLY_NO
	WHERE a.TicketId IN (
'23224',
'23223',
'23222',
'23221',
'23220',
'23219'
	)
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
		and c.EntryDate <= b.ValuationDate
		and c.CLOG_YM ='202108'
		and b.JobName not like '%IRS%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN ([PV])) AS PIVOT_RESULT order by ValuationDate asc



SELECT * FROM (
	SELECT
	'=' as [Valuedate]
	,b.ValuationDate
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE /100000000 as [VALUE]
	FROM Hanwha2Computations.dbo.MarkView A inner join Hanwha2Computations.dbo.job B on a.ticketid = b.TicketId inner join HanwhaInput.dbo.Schedule C on a.RecordId = c.POLY_NO
	WHERE a.TicketId IN (
'22963',
'22962',
'22961',
'22960',
'22959',
'22958'
	)
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
		and c.EntryDate <= b.ValuationDate
		and c.CLOG_YM ='202108'
		and b.JobName not like '%IRS%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN ([PV])) AS PIVOT_RESULT order by ValuationDate asc


SELECT * FROM (
	SELECT
	'=' as [Valuedate]
	,b.ValuationDate
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE /100000000 as [VALUE]
	FROM Hanwha2Computations.dbo.MarkView A inner join Hanwha2Computations.dbo.job B on a.ticketid = b.TicketId inner join HanwhaInput.dbo.Schedule C on a.RecordId = c.POLY_NO
	WHERE a.TicketId IN (
'22587',
'22319',
'22318',
'22316',
'22315',
'22314'
	)
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
		and c.EntryDate < b.ValuationDate
		and c.CLOG_YM ='202108'
		and b.JobName not like '%IRS%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN ([PV])) AS PIVOT_RESULT order by ValuationDate asc


select
	b.ValuationDate,
	sum(case when right(d.productcode, 1) = 'R' then value * d.notional / 1000000000 * -1.0
		 when right(d.productcode, 1) = 'P' then value * d.notional /		1000000000 * 1.0
	end) /10000000 as [PV]
	from Hanwha2Computations.dbo.markview A
	inner join hanwhainput.dbo.IRSwap c on  A.RecordId = C.InstrumentId
	inner join Hanwha2Computations.dbo.job B on b.TicketId = a.TicketId
	inner join hedgeos.dbo.HoldingList d on c.SwapCode = d.ProductCode and d.date = b.ValuationDate
	where d.date >='2021-09-30' and convert(char(10), left(d.productcode, 23)) <> b.ValuationDate 
	and b.ticketid in ()
	group by b.ValuationDate


SELECT * FROM (
	SELECT
	'=' as [Valuedate]
	,b.ValuationDate
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE /100000000 as [VALUE]
	FROM Hanwha2Computations.dbo.MarkView A inner join Hanwha2Computations.dbo.job B on a.ticketid = b.TicketId inner join HanwhaInput.dbo.Schedule C on a.RecordId = c.POLY_NO
	WHERE a.TicketId IN (
'22574',
'22573',
'22571',
'22570',
'22569',
'22562',
'22561',
'22560',
'22559',
'22558',
'22557',
'22550',
'22549',
'22548',
'22547',
'22546',
'22545',
'22538',
'22537',
'22536',
'22535',
'22534',
'22533',
'22526',
'22525',
'22524',
'22523',
'22522',
'22521',
'22514',
'22513',
'22512',
'22511',
'22510',
'22509',
'22502',
'22501',
'22500',
'22499',
'22498',
'22497',
'22490',
'22489',
'22488',
'22487',
'22486',
'22485',
'22478',
'22477',
'22476',
'22475',
'22474',
'22473',
'22466',
'22465',
'22464',
'22463',
'22462',
'22461',
'22454',
'22453',
'22452',
'22451',
'22450',
'22449',
'22442',
'22441',
'22440',
'22439',
'22438',
'22437',
'22430',
'22429',
'22428',
'22427',
'22426',
'22425',
'22418',
'22417',
'22416',
'22415',
'22414',
'22413',
'22406',
'22405',
'22404',
'22403',
'22402',
'22401',
'22394',
'22393',
'22392',
'22391',
'22390',
'22389',
'22382',
'22381',
'22380',
'22379',
'22378',
'22377',
'22370',
'22369',
'22368',
'22367',
'22366',
'22365'
	)
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
		and c.EntryDate <= b.ValuationDate
		and c.CLOG_YM ='202108'
		and b.JobName not like '%IRS%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN ([PV])) AS PIVOT_RESULT order by ValuationDate asc



select
	a.date,
	sum(case when right(a.productcode, 1) = 'R' then value * notional / 1000000000 * -1.0
		 when right(a.productcode, 1) = 'P' then value * notional /		1000000000 * 1.0
	end) /10000000 as [PV]
	from hedgeos.dbo.PV_LH A inner join hedgeos.dbo.holdinglist b on a.date = b.date and a.userid = b.userid and a.ProductCode = b.ProductCode
	where a.Type = 'asset' and a.ProductType <> 'EQ' and a.date >='2021-09-30'
	group by a.date


SELECT
	[Date]
	, [Type]='Asset'
	, [ProductCode] = C.SwapCode
	, [ProductType] = SUBSTRING(C.SwapCode,7,6)
	, [Value] = A.Value
		FROM Hanwha2Computations.dbo.MarkView A
			INNER JOIN Hanwha2Computations.dbo.Job B ON A.TicketId = B.TicketId
			INNER JOIN HanwhaInput.dbo.IRSwap C ON A.RecordId = C.InstrumentId
		WHERE B.JobSetId = @JobSetID 
		AND B.StatusCode = '1'
		AND A.ProductName IN ('SWAPPV')

select
	b.ValuationDate,
	sum(case when right(d.productcode, 1) = 'R' then value * d.notional / 1000000000 * -1.0
		 when right(d.productcode, 1) = 'P' then value * d.notional /		1000000000 * 1.0
	end) /10000000000 as [PV]
	from Hanwha2Computations.dbo.markview A
	inner join hanwhainput.dbo.IRSwap c on  A.RecordId = C.InstrumentId
	inner join Hanwha2Computations.dbo.job B on b.TicketId = a.TicketId
	inner join hedgeos.dbo.HoldingList d on c.SwapCode = d.ProductCode and d.date = b.ValuationDate
	where d.date >='2021-09-30' and convert(char(10), left(d.productcode,6), 23) <> b.ValuationDate 
	and b.ticketid in (
	)
	group by b.ValuationDate

select
	b.ValuationDate,
	d.Date,
	sum(case when right(d.productcode, 1) = 'R' then value * d.notional / 1000000000 * -1.0
		 when right(d.productcode, 1) = 'P' then value * d.notional /		1000000000 * 1.0
	end) /10000000000 as [PV]
	from Hanwha2Computations.dbo.markview A
	inner join hanwha2input.dbo.IRSwap c on  A.RecordId = C.InstrumentId
	inner join Hanwha2Computations.dbo.job B on b.TicketId = a.TicketId
	inner join hedgeos.dbo.HoldingList d on c.SwapCode = d.ProductCode and d.date = b.ValuationDate
	where d.date >='2021-09-30' and c.StartDate <= d.date
	and b.TicketId in (
'23055',
'23053',
'23052',
'23051',
'23049',
'23048',
'23047',
'23045',
'23044',
'23043',
'23042',
'23041',
'23040',
'23039',
'23038',
'23037',
'23036',
'23035',
'23034',
'23049',
'23048',
'23047'
)
	group by b.ValuationDate, d.Date
	order by b.ValuationDate asc


SELECT * FROM (
	SELECT
	'<' as [Valuedate]
	,b.ValuationDate
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE /100000000 as [VALUE]
	FROM Hanwha2Computations.dbo.MarkView A inner join Hanwha2Computations.dbo.job B on a.ticketid = b.TicketId inner join hanwhainput.dbo. C on a.RecordId = c.POLY_NO
	WHERE a.TicketId IN (
'22662',
'22661',
'22660',
'22659',
'22658',
'22657'
	)
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
		and c.EntryDate < b.ValuationDate
		and c.CLOG_YM ='202108'
		and b.JobName not like '%IRS%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN ([PV])) AS PIVOT_RESULT order by ValuationDate asc






/*******************************************************************************************************************************/
SELECT * FROM (
	SELECT
	'<' as [Valuedate]
	,b.ValuationDate
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE /100000000 as [VALUE]
	FROM Hanwha2Computations.dbo.MarkView A inner join Hanwha2Computations.dbo.job B on a.ticketid = b.TicketId inner join HanwhaInput.dbo.Schedule C on a.RecordId = c.POLY_NO
	WHERE a.TicketId IN (
'22662',
'22661',
'22660',
'22659',
'22658',
'22657'
	)
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
		and c.EntryDate < b.ValuationDate
		and c.CLOG_YM ='202108'
		and b.JobName not like '%IRS%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN ([PV])) AS PIVOT_RESULT order by ValuationDate asc

SELECT * FROM (
	SELECT
	'=' as [Valuedate]
	,b.ValuationDate
	, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProductName,'_GMDB',''),'_GMAB',''),'_GMWB',''),'_GLWB',''),'.KRW-IRS',''),'PV.',''),'.KOSPI','') AS ProductName
	, VALUE 
	FROM Hanwha2Computations.dbo.MarkView A inner join Hanwha2Computations.dbo.job B on a.ticketid = b.TicketId inner join HanwhaInput.dbo.Schedule C on a.RecordId = c.POLY_NO
	WHERE a.TicketId IN (
'22254',
'22253',
'22252',
'22251',
'22250',
'22249'
	)
		AND ProductName NOT LIKE '%FEE%'
		AND ProductName NOT LIKE '%REAL%'
		and c.EntryDate <= b.ValuationDate
		and c.CLOG_YM ='202108'
		and b.JobName not like '%IRS%'
) AS RESULT
PIVOT (SUM(VALUE) FOR ProductName IN ([PV])) AS PIVOT_RESULT order by ValuationDate asc
